#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SHIM — «шина» между чекером и НАШИМ сервисом (идея из разбора Савелия,
пункт 1 — самый надёжный и разрешённый: это ТВОЯ коробка).

ЧТО ДЕЛАЕТ
  TCP-прокси: слушает публичный порт, пересылает байты в реальный сервис
  (который переехал на localhost), и ЛОГИРУЕТ оба направления:
    -> чекер -> сервис : путь, тело (там флаг в момент ЗАПИСИ!), flag_id
    <- сервис -> чекер : ответ
  Всё, что похоже на флаг по регулярке, пишется в shim_flags.txt с
  таймстемпом. Это даёт:
    - точный протокол чекера (не гадаем, как он ходит)
    - флаг известен в момент записи (раньше, чем станет читаемым)
    - точный IP/UA чекера (для гейтов и белых списков)

КАК ВСТАВИТЬ (два варианта, оба РУКАМИ и с ТЕСТОМ):
  Вариант A (docker-compose, надёжнее):
    1. в docker-compose сервиса: ports: "127.0.0.1:8081:8080" (реальный
       сервис теперь виден только локально на 8081)
    2. docker compose up -d --build
    3. python3 shim.py --listen 0.0.0.0:8080 --upstream 127.0.0.1:8081
  Вариант B (iptables REDIRECT, если сервис слушает на хосте):
    сервис переносим на 8081 (в его конфиге), затем:
    iptables -t nat -A PREROUTING -p tcp --dport 8080 -j REDIRECT --to-ports 8081
  ОБЯЗАТЕЛЬНО: до старта проверить, что чекерный запрос проходит
  (свой прогон + скорборд зелёный). ШИМ ОБЯЗАН быть прозрачным:
  байты байт-в-байт, полудуплекс не задерживаем.

СТОП-СИГНАЛЫ
  Ctrl-C — шим останавливается, сервис на 8081 продолжает жить локально.
  Вернуть как было: убрать правило iptables / вернуть ports в compose.

ФАЙЛЫ
  shim.log     — весь трафик (обрезано по размеру строки)
  shim_flags.txt — только строки с флагами + время (это наш «ранний лист»)

Только стандартная библиотека. Python 3.8+.
"""
import argparse
import base64
import os
import re
import socket
import subprocess
import sys
import threading
import time

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(SELF_DIR, "shim.log")
FLAGS_PATH = os.path.join(SELF_DIR, "shim_flags.txt")
MAX_LINE = 2000          # сколько байт строки пишем в лог
MAX_LOG_MB = 50          # ротация лога (иначе забьёт диск — нельзя)

lock = threading.Lock()
flag_re = None
stats = {"conn": 0, "flags": 0}


def log_line(direction, data):
    """Пишем кусок трафика в shim.log (обрезанный, с направлением)."""
    try:
        text = data.decode("utf-8", "replace")
    except Exception:  # noqa: BLE001
        text = base64.b64encode(data[:200]).decode("ascii", "replace")
    text = text.replace("\r", "\\r").replace("\n", "\\n")[:MAX_LINE]
    with lock:
        try:
            # ротация: лог вырос — переносим в .old (просто и предсказуемо)
            if os.path.exists(LOG_PATH) and os.path.getsize(LOG_PATH) > MAX_LOG_MB * 1024 * 1024:
                os.replace(LOG_PATH, LOG_PATH + ".old")
            with open(LOG_PATH, "a", encoding="utf-8") as f:
                f.write("%s %s %s\n" % (time.strftime("%H:%M:%S"), direction, text))
        except OSError:
            pass


def extract_flags(data):
    """Достаём флаги из куска трафика и пишем в shim_flags.txt с временем.

    Это «флаг в момент записи»: чекер кладёт флаг в наш сервис — мы
    узнаём его сразу, не дожидаясь, пока он станет читаемым через баг.
    СВОИ флаги сдавать нельзя (ForcAD: FLAG_YOUR_OWN) — но мы видим
    протокол и точный формат, а чужие флаги потом сравним с этим
    шаблоном (первая буква = имя сервиса, см. playbook.md).
    """
    if not flag_re:
        return
    found = flag_re.findall(data.decode("utf-8", "replace"))
    if not found:
        return
    with lock:
        try:
            with open(FLAGS_PATH, "a", encoding="utf-8") as f:
                for fl in found:
                    f.write("%s %s\n" % (time.strftime("%H:%M:%S"), fl))
                    stats["flags"] += 1
        except OSError:
            pass


def pipe(src, dst, direction):
    """Перекачка байтов в одну сторону + лог. Живёт в своём потоке."""
    try:
        while True:
            chunk = src.recv(65536)
            if not chunk:
                break
            dst.sendall(chunk)
            log_line(direction, chunk)
            extract_flags(chunk)
    except OSError:
        pass
    finally:
        try:
            dst.shutdown(socket.SHUT_WR)
        except OSError:
            pass


def handle(client, upstream_addr):
    """Одно соединение: подключаемся к реальному сервису и молча перекачиваем."""
    stats["conn"] += 1
    try:
        upstream = socket.create_connection(upstream_addr, timeout=10)
    except OSError as e:
        # реальный сервис недоступен: закрываем чекеру соединение.
        # НИЧЕГО не отвечаем сами (не выдумываем ответы — это сломало бы чекер).
        log_line("ERR", ("upstream down: %s" % e).encode())
        client.close()
        return
    t1 = threading.Thread(target=pipe, args=(client, upstream, "C->S"), daemon=True)
    t2 = threading.Thread(target=pipe, args=(upstream, client, "S->C"), daemon=True)
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    try:
        client.close()
    except OSError:
        pass
    try:
        upstream.close()
    except OSError:
        pass


def parse_addr(s, default_port=8080):
    """'0.0.0.0:8080' или ':8080' -> (host, port)."""
    if ":" in s:
        host, port = s.rsplit(":", 1)
        return (host or "0.0.0.0"), int(port)
    return "0.0.0.0", int(s)


def main(argv=None):
    global flag_re
    ap = argparse.ArgumentParser(description="SHIM — прозрачный логирующий прокси чекер->сервис")
    ap.add_argument("--listen", default="0.0.0.0:8080", help="что слушаем (публичный порт сервиса)")
    ap.add_argument("--upstream", default="127.0.0.1:8081", help="куда пересылать (реальный сервис)")
    ap.add_argument("--regex", default="[A-Z0-9]{31}=", help="регулярка флага (сверяй с tune.py)")
    ap.add_argument("--check", action="store_true", help="только проверить связь с upstream и выйти")
    args = ap.parse_args(argv)

    try:
        flag_re = re.compile(args.regex)
    except re.error as e:
        print("плохая регулярка: %s" % e)
        return 2

    up = parse_addr(args.upstream)
    lst = parse_addr(args.listen)

    if args.check:
        try:
            s = socket.create_connection(up, timeout=5)
            s.close()
            print("upstream %s:%d отвечает (TCP). Шим можно ставить." % up)
            return 0
        except OSError as e:
            print("upstream %s:%d НЕ отвечает: %s — сначала перенеси сервис, потом шим" % (up[0], up[1], e))
            return 1

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(lst)
    srv.listen(50)
    print("SHIM: %s:%d -> %s:%d  (лог: %s, флаги: %s)" % (
        lst[0], lst[1], up[0], up[1], LOG_PATH, FLAGS_PATH))
    print("Ctrl-C — остановить. Проверь, что скорборд зелёный!")
    try:
        while True:
            client, addr = srv.accept()
            threading.Thread(target=handle, args=(client, up), daemon=True).start()
    except KeyboardInterrupt:
        print("\nSHIM остановлен. Соединений: %d, флагов увидено: %d" % (
            stats["conn"], stats["flags"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
