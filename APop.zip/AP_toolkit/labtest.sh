#!/usr/bin/env bash
# ============================================================
#  LABTEST — проверка ОБОИХ целей НА ПРАКТИКЕ. Запускать дома на своей Kali:
#
#      bash labtest.sh
#
#  ЦЕЛЬ 1 «чужие флаги заберём»:
#      поднимаем ЛОКАЛЬНЫЙ ssh-сервер (он изображает вулнбокс соперника),
#      кладём в него тестовые флаги + запускаем НАСТОЯЩУЮ ферму (farm.py)
#      против него. Если ферма нашла флаги — цель доказана.
#      Нужен sudo (apt install openssh-server, если его нет).
#
#  ЦЕЛЬ 2 «наши флаги не заберут»:
#      ставим tripwire в песочницу (без рута, AP_ROOT переопределён),
#      изображаем соперника: «читаем» канарейки и подкладываем ключ.
#      Если вотчдог поймал — цель доказана.
#
#  Всё живёт в /tmp/ap_labtest.$$, система не портится. В конце — вердикт
#  ПРАКТИКА ПРОЙДЕНА / ПРОВАЛЕНА и что именно проверено.
# ============================================================
set -uo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
LAB=/tmp/ap_labtest.$$
mkdir -p "$LAB"
PASS=0; FAIL=0

ok()   { PASS=$((PASS+1)); printf '\033[1;32m[PASS]\033[0m %s\n' "$*"; }
bad()  { FAIL=$((FAIL+1)); printf '\033[1;31m[FAIL]\033[0m %s\n' "$*"; }
step() { printf '\033[1;36m-- %s\033[0m\n' "$*"; }

cleanup() {
    # убрать всё, что заводили (sshd, юзера, песочницу)
    if [ -f "$LAB/sshd.pid" ]; then
        sudo kill "$(cat "$LAB/sshd.pid")" 2>/dev/null
    fi
    if [ "${LAB_USER_CREATED:-0}" = "1" ]; then
        sudo userdel -r ap_lab 2>/dev/null
    fi
    # вернуть БОЕВОЙ canaries.txt, если он был (лабтест перезаписывал его тестовым)
    if [ -f "$HERE/canaries.txt.lab.bak" ]; then
        mv "$HERE/canaries.txt.lab.bak" "$HERE/canaries.txt" 2>/dev/null
    fi
    rm -rf "$LAB"
}
trap cleanup EXIT

# ============================================================
step "ЧАСТЬ A. Наши флаги не заберут (канарейки + детектор)"
# ============================================================
# tripwire в тестовом режиме: AP_ROOT и DECOY в песочнице, рут не нужен
export AP_ROOT="$LAB/root"
export DECOY="$LAB/flags-decoy"
mkdir -p "$AP_ROOT" "$DECOY"
# БОЕВОЙ canaries.txt прячем (лабтест перезапишет тестовым — потом вернём)
[ -f "$HERE/canaries.txt" ] && cp "$HERE/canaries.txt" "$HERE/canaries.txt.lab.bak"

if TRIP_TEST=1 bash "$HERE/tripwire.sh" install >/dev/null 2>&1; then
    # TRIP_TEST=1: install не запускает вотчдог сам — лабтест стартует его руками
    # и убивает после проверки (иначе вечный процесс висит в системе)
    N=$(grep -cE '[A-Z0-9]' "$HERE/canaries.txt" 2>/dev/null || echo 0)
    if [ "${N:-0}" -ge 25 ]; then
        ok "канарейки сгенерированы: $N пустышек в canaries.txt"
    else
        bad "мало пустышек: $N (ожидали >=25)"
    fi
    # канарейка обязана совпадать с регуляркой флага (иначе соперник её не подберёт)
    SAMPLE=$(grep -E '^[A-Z0-9]' "$HERE/canaries.txt" | head -1)
    RX=$(python3 - <<PYEOF
import json, sys
sys.path.insert(0, "$HERE")
from farm import DEFAULTS
print(DEFAULTS["flag_regex"])
PYEOF
)
    if echo "$SAMPLE" | grep -qE "$RX"; then
        ok "пустышка совпадает с регуляркой флага ($RX)"
    else
        bad "пустышка НЕ совпадает с регуляркой: $SAMPLE"
    fi
else
    bad "tripwire install упал"
fi

# вотчдог: запускаем руками на 8 секунд и изображаем соперника
if [ -x "$AP_ROOT/ap-tripwatch.sh" ]; then
    sh "$AP_ROOT/ap-tripwatch.sh" &
    WPID=$!
    sleep 1
    DECOY_DIR="${DECOY:-/flags-decoy}"
    [ -d "$DECOY_DIR" ] || DECOY_DIR="$LAB/flags-decoy"   # если settings.env переопределил
    # «соперник» читает канарейки (find новее маркера) и правит authorized_keys
    touch "$DECOY_DIR"/flag_round_1.txt 2>/dev/null
    mkdir -p "$AP_ROOT/.ssh" && echo "ssh-rsa AAAA-rival-key" >> "$AP_ROOT/.ssh/authorized_keys"
    sleep 7
    kill $WPID 2>/dev/null
    if grep -q "КАНАРЕЙКА" "$AP_ROOT/tripwire.log" 2>/dev/null; then
        ok "вотчдог ПОЙМАЛ чтение канареек"
    else
        bad "вотчдог не заметил чтение канареек"
    fi
    if grep -q "authorized_keys" "$AP_ROOT/tripwire.log" 2>/dev/null; then
        ok "вотчдог ПОЙМАЛ подмену authorized_keys"
    else
        bad "вотчдог не заметил подмену ключей"
    fi
else
    bad "вотчдог не создан"
fi

# ферма обязана отказаться сдавать нашу же пустышку
if python3 "$HERE/farm.py" --selftest >/dev/null 2>&1; then
    ok "farm selftest (включая исключение канареек из сдачи)"
else
    bad "farm selftest упал"
fi

# ============================================================
step "ЧАСТЬ B. Чужие флаги заберём (ферма против живого SSH)"
# ============================================================
if [ ! -x "$(command -v sshd)" ]; then
    if command -v apt-get >/dev/null 2>&1 && sudo -n true 2>/dev/null; then
        sudo apt-get install -y openssh-server >/dev/null 2>&1
    fi
fi

if [ ! -x "$(command -v sshd)" ]; then
    echo "  [SKIP] sshd не установлен и sudo недоступен — Часть B прогони дома на Kali:"
    echo "         sudo apt install openssh-server && bash labtest.sh"
    FAIL=$((FAIL))
else
    # 1) тестовый «вулнбокс соперника»: юзер ap_lab с известным паролем
    if id ap_lab >/dev/null 2>&1; then
        sudo userdel -r ap_lab 2>/dev/null
    fi
    sudo useradd -m -s /bin/bash ap_lab 2>/dev/null \
        && echo 'ap_lab:labpass123' | sudo chpasswd \
        && LAB_USER_CREATED=1 \
        && ok "тест-пользователь ap_lab создан (пароль labpass123)" \
        || bad "не удалось создать тест-пользователя"

    # 2) «сервисы соперника»: флаги там, где их ищет охота
    SVC="$LAB/svc"; HOME_LAB=$(getent passwd ap_lab | cut -d: -f6)
    mkdir -p "$SVC" "$HOME_LAB/.config"
    F1="T1E2S3T4F5L6A7G8H9E1R2E3V4E5R6Y=";   # тестовый «флаг» (формат совпадает)
    F2="A1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P="
    echo "secret data $F1" > "$SVC/flag.txt"
    echo "config $F2" > "$HOME_LAB/.config/svc.conf"
    # канарейка «соперника» (у него тоже могут быть пустышки — наша ферма
    # НЕ знает его canaries.txt, поэтому сдаст — это норм: она думает, что живая)
    sudo chown -R ap_lab:ap_lab "$HOME_LAB" 2>/dev/null

    # 3) sshd на 2222
    cat > "$LAB/sshd_config" <<EOF
Port 2222
ListenAddress 127.0.0.1
HostKey /etc/ssh/ssh_host_rsa_key
PasswordAuthentication yes
PermitRootLogin no
UsePAM yes
PidFile $LAB/sshd.pid
EOF
    sudo mkdir -p /run/sshd
    sudo /usr/sbin/sshd -f "$LAB/sshd_config" -E "$LAB/sshd.log" 2>/dev/null \
        && ok "локальный sshd поднят на 127.0.0.1:2222" \
        || bad "sshd не поднялся (смотри $LAB/sshd.log)"

    # 4) лабовая конфигурация фермы: 1 «команда» = этот sshd
    cat > "$LAB/farm.json" <<EOF
{
  "subnet_template": "127.0.0.1",
  "first_team": 1, "last_team": 1, "my_team": 0,
  "creds": [{"user": "ap_lab", "pass": "labpass123"}],
  "ssh_port": 2222,
  "hunt_roots": ["$SVC", "$HOME_LAB"],
  "checksystem_host": "127.0.0.1", "checksystem_port": 13133,
  "protocol": "tcp", "team_token": "LAB", "flag_regex": "[A-Z0-9]{31}=",
  "state_file": "lab_state.json", "log_file": "$LAB/farm.log",
  "sploits_dir": "sploits"
}
EOF

    # 5) РЕАЛЬНЫЙ sweep: ферма обязана найти юзера/пароль на живом SSH
    if cd "$HERE" && python3 farm.py --config "$LAB/farm.json" --sweep 2>&1 | grep -q "ap_lab"; then
        ok "sweep: ферма зашла на живой SSH по паролю"
    else
        bad "sweep: ферма НЕ зашла (нужен sshpass или OpenSSH>=8.4 с setsid)"
    fi

    # 6) РЕАЛЬНАЯ охота (dry-run: сдача в никуда 127.0.0.1:13133 — просто TCP-ошибка, ферма её переживёт)
    OUT=$(cd "$HERE" && python3 farm.py --config "$LAB/farm.json" --once --dry-run 2>&1)
    FOUND=0
    echo "$OUT" | grep -q "$F1" && FOUND=$((FOUND+1))
    echo "$OUT" | grep -q "$F2" && FOUND=$((FOUND+1))
    if [ "$FOUND" -ge 2 ]; then
        ok "охота: оба тестовых флага найдены в файлах жертвы"
    elif [ "$FOUND" -eq 1 ]; then
        ok "охота: найден 1 из 2 флагов"
        bad "второй флаг не найден — проверь hunt_roots"
    else
        bad "охота: флаги НЕ найдены — ssh-канал или payload сломаны"
    fi
fi

# ============================================================
step "ИТОГ"
# ============================================================
echo
echo "  прошло: $PASS, упало: $FAIL"
if [ "$FAIL" -eq 0 ] && [ "$PASS" -ge 5 ]; then
    printf '\033[1;32m  ПРАКТИКА ПРОЙДЕНА: чужие флаги забираем (часть B),\033[0m\n'
    printf '\033[1;32m  наши защищены канарейками и ферма не сдаёт пустышки (часть A).\033[0m\n'
    exit 0
else
    printf '\033[1;31m  ПРАКТИКА С ПРОВАЛАМИ — разбери [FAIL] выше до игры.\033[0m\n'
    exit 1
fi
