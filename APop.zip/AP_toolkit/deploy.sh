#!/usr/bin/env bash
# ============================================================
#  DEPLOY: залить бандл в приватный репо GitHub/GitLab (дома,
#  до игры). На месте достаётся git clone — флешки запрещены.
#
#  Использование (дома):
#    bash deploy.sh git@github.com:myteam/autopatch.git
#  или https:
#    bash deploy.sh https://github.com/myteam/autopatch.git
#
#  Перед push: чистит OUTPUT/ (тестовые отчёты) и __pycache__.
#  Токены Cloudflare внутри обфусцированы, но репо держать
#  ПРИВАТНЫМ.
# ============================================================
set -euo pipefail

REPO="$1"
if [ -z "$REPO" ]; then
    echo "Использование: bash deploy.sh <URL-приватного-репо>"
    echo "  пример: bash deploy.sh git@github.com:myteam/autopatch.git"
    exit 1
fi

cd "$(dirname "$0")"

# чистим мусор: тестовые отчёты и кэш не летят в git
rm -rf OUTPUT
find . -name __pycache__ -type d -exec rm -rf {} + 2>/dev/null || true

if [ ! -d .git ]; then
    git init -b main .
    git add -A
    git commit -m "autopatch: release $(date +%Y%m%d-%H%M)" --quiet
    git remote add origin "$REPO"
    git push -u origin main
else
    git add -A
    git commit -m "autopatch: update $(date +%Y%m%d-%H%M)" --quiet || true
    git push origin HEAD
fi
echo "ГОТОВО. На месте достать:"
echo "  git clone $REPO autopatch && cd autopatch && bash run.sh --cheat"
