# -*- coding: utf-8 -*-
"""Самотест: специально уязвимый мини-сервис (объединяет паттерны реальных игр)."""
import os
import random
import sqlite3
import subprocess

from flask import Flask, request, send_file, render_template_string

app = Flask(__name__)
app.config["SECRET_KEY"] = "uhn7/K4sepyMIQlNxiVhC8EQQGj+cQqPfvba98d1Vgg="
DATA_DIR = "/srv/data"


@app.route("/notes")
def notes():
    username = request.args.get("user", "")
    cur = sqlite3.connect("db.sqlite").cursor()
    cur.execute(f"SELECT * FROM notes WHERE user = '{username}'")  # SQLi
    return str(cur.fetchall())


@app.route("/ping")
def ping():
    ip = request.args["ip"]
    os.system(f"ping -c1 {ip}")  # CmdInjection
    return "ok"


@app.route("/note/<int:nid>")
def note(nid):
    note = Note.query.get(nid)  # IDOR
    return str(note)


@app.route("/greet")
def greet():
    name = request.args.get("name", "")
    return render_template_string("Привет, " + name + "!")  # SSTI


@app.route("/download")
def download():
    return send_file(os.path.join(DATA_DIR, request.args["name"]))  # PathTraversal


@app.route("/import")
def do_import():
    data = request.get_data()
    import pickle
    pickle.loads(data)  # Deserialize
    return "ok"


@app.route("/convert")
def convert():
    src = request.args["src"]
    subprocess.call(f"convert {src} out.png", shell=True)  # CmdInjection
    return "ok"


def make_token():
    return str(random.randint(10**9, 10**10))  # WeakCrypto


@app.route("/xml")
def xml():
    import xml.etree.ElementTree as ET
    ET.fromstring(request.data)  # XXE
    return "ok"


@app.route("/health")
def health():
    return {"token": make_token()}
