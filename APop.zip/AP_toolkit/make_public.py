#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MAKE PUBLIC — собирает ЧИСТУЮ копию кита для публичного GitHub-репозитория.

ЧТО ВАЖНО ЗНАТЬ
  В ките лежат вещи, которые НЕЛЬЗЯ выкладывать в открытый репо:
    - обфусцированные токены Cloudflare (ap/config.json) -> заменяем пустыми;
    - наш боевой конфиг farm.json (пароли соседей, team_token) -> не копируем;
    - state-файлы и журналы (что сдали, кого поймали) -> не копируем;
    - ai_e2e_result.md (внутренний отчёт с фрагментами токенов) -> не копируем.
  Скрипт проверяет результат: если в копии встретился 'cfut_' — АВАРИЙНЫЙ
  СТОП (ничего не публикуем).

ЗАПУСК
  python3 make_public.py                     # -> ../AP_toolkit_public
  python3 make_public.py --out /tmp/pub      # свой путь

ДАЛЬШЕ (команды напечатает сам скрипт):
  git init, commit, remote add origin git@github.com:USER/REPO.git, push.
  Репо можно создавать у себя на ноутбуке ДО выезда (на игре внешние POST
  закрыты — GitHub там недоступен для логина).
"""
import argparse
import json
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

# что НЕ попадает в публичную копию (по именам/суффиксам)
EXCLUDE_FILES = {
    "farm.json",            # боевой конфиг: team_token, креды соседей
    "ai_e2e_result.md",     # внутренний отчёт: упоминаются фрагменты токенов
    "sniff_state.json", "farm_state.json", "shim_flags.txt",
    "sniffed.jsonl", "shim.log", "sniff.log",
    "canaries.txt", "denylist.txt",   # наши канарейки и deny — своя игра
    "deploy.sh",            # приватный deploy-сценарий команды
}
EXCLUDE_SUFFIX = (".pyc", ".pyo", ".log", ".state", ".jsonl")
EXCLUDE_DIRS = {"OUTPUT", "__pycache__", ".git"}

LICENSE = """MIT License

Copyright (c) 2026 InnoCTF Junior A/D toolkit authors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

GITIGNORE = """# боевое состояние и секреты — никогда не коммитим
farm.json
canaries.txt
denylist.txt
sniff_state.json
farm_state.json
shim_flags.txt
shim.log
sniff.log
sniffed.jsonl
ai_e2e_result.md
OUTPUT/
__pycache__/
*.pyc
*.log
"""

README_MD = """# AP toolkit — Attack/Defense CTF starter kit (InnoCTF Junior)

Набор инструментов для Attack-Defense CTF (формат ForcAD): автоанализ
сервисов на уязвимости, ферма сдачи флагов, снифер чужих флагов, канарейки
и автопатч-подсказки. ИИ-слой — Cloudflare Workers AI (каскад моделей с
офлайн-деградацией).

**EN:** Attack/Defense CTF toolkit: vulnerability analyzer for service
sources, flag farm, network flag sniffer, canary/decoy tripwire. AI layer
uses Cloudflare Workers AI with offline fallback. **CTF/educational use
only — run only on networks you are explicitly authorized to attack.
ARP/MITM modes require explicit permission from the event rules.**

## Состав

| Файл | Что делает |
|---|---|
| `autopatch.py` | сканирует исходники сервиса: офлайн-грепы + досье 15 сервисов прошлых лет + ИИ-разбор; печатает план патчей |
| `farm.py` | ферма: sweep дефолтных SSH-кредов по подсети, чтение флагов, сплойты `sploits/*.py`, автосдача |
| `sniffer.py` | пассивный сниф эфира + опциональный ARP-MITM с авторемонтом; ловит чужие флаги (в т.ч. в URL-коде/base64), авто-deny лжефлагов |
| `shim.py` | прозрачный TCP-шим «чекер -> наш сервис»: видит флаг в момент записи |
| `harden.sh` | 3 минуты на вулнбоксе: пароли, SSH-конфиг, git-бэкап сервисов, tcpdump |
| `tripwire.sh` | канарейки-пустышки (`/flags-decoy/`) + watchdog на вторжение |
| `ap_quota_probe.py` | микро-зонд квоты Cloudflare (ноль расхода, пока квота пуста) |
| `token_setup.py` | обфускация CF-токена в `ap/config.json` |
| `tune.py` | одна кнопка замены всех вводных (номер команды, токен, креды) |
| `labtest.sh` | домашняя проверка обоих инструментов до выезда |

## Быстрый старт

```bash
python3 autopatch.py --selftest        # офлайн-проверка тула
python3 sniffer.py --selftest          # проверка снифера
python3 farm.py --init                 # создать farm.json и заполнить
python3 tune.py                        # вбить вводные одной командой
python3 token_setup.py cfut_...        # вставить свой CF-токен
sudo python3 sniffer.py --passive --dry-run   # безопасный первый запуск
```

## Токены Cloudflare

В `ap/config.json` токены ПУСТЫЕ. Получи свой API-токен (Workers AI,
10 000 нейронов/сутки бесплатно) и выполни `token_setup.py`. Без токена
`autopatch.py` работает офлайн: грепы и досье не требуют ИИ.

## Этические границы (зашиты в код и в README не просто так)

- Инструменты ЧИТАЮТ флаги и сдают их, но не ломают чужие сервисы:
  DoS чужого вулнбокса в большинстве регламентов = дисквалификация,
  а мёртвый сервис не приносит очков никому, включая тебя.
- Снифер не дропает и не подменяет трафик: только чтение + авторемонт ARP.
- Канарейки-пустышки допустимы; подмена флагов в чужих запросах — нет.

## Лицензия

MIT — см. [LICENSE](LICENSE).
"""


def copy_tree(dst):
    """Рекурсивное копирование кита с фильтрами. Возвращает список файлов."""
    copied = []
    for dp, dn, fs in os.walk(HERE):
        dn[:] = [d for d in dn if d not in EXCLUDE_DIRS]
        for f in fs:
            if f in EXCLUDE_FILES or f.endswith(EXCLUDE_SUFFIX):
                continue
            src = os.path.join(dp, f)
            rel = os.path.relpath(src, HERE)
            out = os.path.join(dst, rel)
            os.makedirs(os.path.dirname(out), exist_ok=True)
            shutil.copy2(src, out)
            copied.append(rel)
    return copied


def sanitize_config(path):
    """Публичный config.json: токены ПУСТЫЕ + пометка _PUBLIC."""
    with open(path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    cfg["token_obf"] = ""
    cfg["token2_obf"] = ""
    cfg["_hint"] = ("ПУБЛИЧНАЯ КОПИЯ: токены пустые. Вставь свои через "
                    "python3 token_setup.py cfut_... Квота: 10k нейронов/сутки, "
                    "сброс 00:00 UTC.")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def leak_check(dst):
    """Аварийный стоп, если в публичной копии всплыл РЕАЛЬНЫЙ токен.
    Регэекс под живой токен CF: cfut_ + 30+ латинских букв/цифр.
    Документационные «cfut_...» и «cfut_ВАШТОКЕН» не считаются утечкой."""
    pat = re.compile(rb"cfut_[A-Za-z0-9]{30,}")
    hits = []
    for dp, dn, fs in os.walk(dst):
        dn[:] = [d for d in dn if d not in EXCLUDE_DIRS]
        for f in fs:
            p = os.path.join(dp, f)
            try:
                with open(p, "rb") as fh:
                    if pat.search(fh.read()):
                        hits.append(os.path.relpath(p, dst))
            except OSError:
                pass
    return hits


def main():
    ap = argparse.ArgumentParser(description="Публичная копия кита для GitHub")
    ap.add_argument("--out", default=os.path.join(HERE, "..", "AP_toolkit_public"))
    args = ap.parse_args()
    dst = os.path.abspath(args.out)

    if os.path.exists(dst):
        shutil.rmtree(dst)
    os.makedirs(dst)

    files = copy_tree(dst)
    sanitize_config(os.path.join(dst, "ap", "config.json"))
    with open(os.path.join(dst, "LICENSE"), "w", encoding="utf-8") as f:
        f.write(LICENSE)
    with open(os.path.join(dst, ".gitignore"), "w", encoding="utf-8") as f:
        f.write(GITIGNORE)
    with open(os.path.join(dst, "README.md"), "w", encoding="utf-8") as f:
        f.write(README_MD)
    files += ["LICENSE", ".gitignore", "README.md"]

    hits = leak_check(dst)
    if hits:
        print("!! АВАРИЙНЫЙ СТОП: в публичной копии найден 'cfut_': %s" % hits)
        print("   НИЧЕГО НЕ ПУБЛИКУЙ. Разберись и перезапусти make_public.py.")
        sys.exit(3)

    print("Публичная копия: %s (%d файлов)" % (dst, len(files)))
    print("Токены очищены, боевые файлы исключены. Далее на ноутбуке:")
    print("  cd %s" % dst)
    print("  git init && git add -A && git commit -m 'AP toolkit: InnoCTF Junior A/D starter kit'")
    print("  git remote add origin git@github.com:ТВОЙ_НИК/имя_репо.git")
    print("  git branch -M main && git push -u origin main")
    print("Готовый README.md/.gitignore/LICENSE уже в папке.")


if __name__ == "__main__":
    main()
