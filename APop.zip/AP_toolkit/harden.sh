#!/usr/bin/env bash
# ============================================================
#  HARDEN — защита своего вулнбокса за 3 минуты (до 10:40!)
#
#  Стадия 1: bash harden.sh
#     - сменить пароли ВСЕМ учёткам (root + все с шеллом)
#     - бэкап сервисов tar + git init в каждом сервисе
#     - tcpdump в запись (если не запущен)
#     Парольный вход ОСТАЁТСЯ (чтобы не запереть самих себя).
#  Стадия 2: bash harden.sh --lock
#     - ПОСЛЕ того как проверил: ключом заходит, паролем знаешь
#     - отключает PasswordAuthentication в sshd (Ubuntu 26:
#       neutralит и sshd_config.d/*.conf, где cloud-init
#       может перебивать настройки)
#  Проверка: bash harden.sh --check
# ============================================================
set -uo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
# --- подстройка вводных: settings.env пишет tune.py -------------------
[ -f "$HERE/settings.env" ] && . "$HERE/settings.env"

SSH_CFG=/etc/ssh/sshd_config
SSHD_DIR=/etc/ssh/sshd_config.d
HARDEN_CONF=$SSHD_DIR/99-autopatch-harden.conf

say() { printf '\033[1;36m>> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m!! %s\033[0m\n' "$*"; }
die() { printf '\033[1;31mXX %s\033[0m\n' "$*"; exit 1; }

if [ "${1:-}" != "--dry" ] && [ "$(id -u)" -ne 0 ]; then
    die "запусти от root: sudo bash harden.sh (или сначала --dry, чтобы просто посмотреть план)"
fi

shell_users() {
    # все учётки с шеллом — именно им меняем пароли (из AP_PASSWD в тестах)
    awk -F: '$7 ~ /(bash|sh|zsh)$/ {print $1}' "${AP_PASSWD:-/etc/passwd}"
}

# ---------------- сухой прогон (ничего не меняет!) ----------------
dry() {
    say "ПЛАН (ничего не выполняется, только показать):"
    echo " 1) сменить пароль учёткам: $(shell_users | tr '\n' ' ')"
    echo " 2) бэкап сервисов: tar czf /root/ad_backups/services-*.tar.gz"
    echo "    (каталог авто-поиск: /services /opt/services /srv/services /srv /opt)"
    echo " 3) git init в каждом сервисе + первый коммит"
    echo " 4) tcpdump -i any -w /root/capture.pcap (если ещё не пишет)"
    echo " 5) после проверки ключа: --lock выключит парольный SSH"
    echo ""
    echo " -- текущие учётки с шеллом: $(shell_users | tr '\n' ' ')"
    sshd -T 2>/dev/null | grep -Ei 'passwordauthentication|permitrootlogin' \
        || echo " -- sshd -T недоступен (не root) — настройка покажется при запуске"
    echo " -- tcpdump: $(pgrep -x tcpdump >/dev/null 2>&1 && echo пишет || echo НЕ пишет)"
}

# ---------------- стадия 1 ----------------
stage1() {
    say "СТАДИЯ 1: пароли + бэкапы + прослушка"

    printf 'Новый пароль (один для всех учёток, не говори никому): '
    read -rs PASS
    echo
    [ ${#PASS} -ge 8 ] || die "короче 8 символов — не пойдёт, дефолт угадают"
    printf 'Ещё раз: '
    read -rs PASS2
    echo
    [ "$PASS" = "$PASS2" ] || die "не совпали"

    for u in $(shell_users); do
        printf '%s:%s\n' "$u" "$PASS" | chpasswd && say "пароль сменён: $u"
    done

    # сервисные каталоги: где лежат сервисы
    SVC=""
    for d in /services /opt/services /srv/services /srv /opt; do
        [ -d "$d" ] && SVC="$d" && break
    done
    [ -z "$SVC" ] && { printf 'Где лежат сервисы (путь): '; read -r SVC; }
    if [ -n "$SVC" ] && [ -d "$SVC" ]; then
        mkdir -p /root/ad_backups
        tar czf "/root/ad_backups/services-$(date +%s).tar.gz" -C "$SVC" . 2>/dev/null
        say "бэкап: /root/ad_backups/services-*.tar.gz"
        find "$SVC" -maxdepth 2 -name docker-compose.y\* -o -maxdepth 2 -name Dockerfile 2>/dev/null | cut -d/ -f1-4 | sort -u | while read -r s; do
            (cd "$s" && git init -q 2>/dev/null; git add -A 2>/dev/null; git -c user.email=a@a -c user.name=ap commit -qm initial 2>/dev/null)
        done
        say "git-контроль в сервисах: done"
    else
        warn "каталог сервисов не найден — бэкап руками: tar czf /root/svc.tgz -C <путь> ."
    fi

    if ! pgrep -x tcpdump >/dev/null 2>&1; then
        command -v tcpdump >/dev/null 2>&1 || warn "tcpdump нет — apt install tcpdump (до 10:00 сеть закрыта, можно)"
        nohup tcpdump -i any -w /root/capture.pcap >/dev/null 2>&1 &
        say "tcpdump пишет в /root/capture.pcap"
    else
        say "tcpdump уже пишет"
    fi

    echo
    say "СТАДИЯ 1 ГОТОВА. Дальше по порядку:"
    echo "   1) с Kali: ssh-copy-id $(id -un)@$(hostname -I | awk '{print $1}')  (пароль уже новый)"
    echo "   2) проверь: ключом заходит, паролем тоже"
    echo "   3) bash harden.sh --lock   # выключит парольный вход насмерть"
}

# ---------------- стадия 2 ----------------
stage2() {
    say "СТАДИЯ 2: отключаем парольный SSH"
    if [ ! -s "$HOME/.ssh/authorized_keys" ] && [ ! -s "/root/.ssh/authorized_keys" ]; then
        warn "authorized_keys ПУСТ — сначала ssh-copy-id, иначе ЗАПРЁШ СЕБЯ"
        printf 'Всё равно продолжаем? (yes/no): '
        read -r r
        [ "$r" = "yes" ] || die "отменено (правильно)"
    fi
    printf 'Ключ проверен, заходит? Вводим yes: '
    read -r r
    [ "$r" = "yes" ] || die "сначала проверь ключ"

    cp "$SSH_CFG" /root/sshd_config.bak.$(date +%s)
    mkdir -p "$SSHD_DIR"
    # перебить ранние дропы cloud-init'а (50-cloud-init.conf и пр.)
    for f in "$SSHD_DIR"/*.conf; do
        [ -f "$f" ] && [ "$(basename "$f")" != "$(basename "$HARDEN_CONF")" ] || continue
        sed -i 's/^[[:space:]]*PasswordAuthentication[[:space:]]*yes/#AP-neutralized PasswordAuthentication yes/I; s/^[[:space:]]*PermitRootLogin[[:space:]]*yes/#AP-neutralized PermitRootLogin yes/I' "$f" 2>/dev/null
    done
    cat > "$HARDEN_CONF" <<'EOF'
PasswordAuthentication no
KbdInteractiveAuthentication no
PermitRootLogin prohibit-password
ChallengeResponseAuthentication no
EOF
    # и в главном конфиге тоже, на всякий
    sed -i 's/^#?[[:space:]]*PasswordAuthentication.*/PasswordAuthentication no/; s/^#?[[:space:]]*PermitRootLogin.*/PermitRootLogin prohibit-password/' "$SSH_CFG" 2>/dev/null

    sshd -t 2>/dev/null || { cp /root/sshd_config.bak.* "$(ls -t /root/sshd_config.bak.* | head -1)" "$SSH_CFG" 2>/dev/null; die "sshd_config сломан — ОТКАТИЛ, смотри руками"; }
    systemctl restart ssh 2>/dev/null || service ssh restart 2>/dev/null || warn "ssh не рестартанулся — проверь руками systemctl restart ssh"

    say "Парольный SSH ВЫКЛЮЧЕН. Проверь из Kali:"
    echo "   ssh $(id -un)@$(hostname -I | awk '{print $1}')   # должно пустить по ключу"
    sshd -T 2>/dev/null | grep -i passwordauthentication || true
}

# ---------------- проверка ----------------
check() {
    say "статус защиты:"
    echo " -- учётки с шеллом: $(shell_users | tr '\n' ' ')"
    sshd -T 2>/dev/null | grep -Ei 'passwordauthentication|permitrootlogin' || grep -Ei 'Password|PermitRoot' "$SSH_CFG"
    echo " -- authorized_keys: $(cat /root/.ssh/authorized_keys 2>/dev/null | wc -l) ключ(ей) root"
    # лишние ключи: смотрим authorized_keys ВСЕХ учёток с шеллом —
    # чужой ключ в чужой учётке = чужой вход мимо нашей гигиены
    for u in $(shell_users); do
        [ "$u" = "root" ] && continue
        f=$(awk -F: -v u="$u" '$1==u {print $6}' /etc/passwd 2>/dev/null)/.ssh/authorized_keys
        n=$(grep -cv -e '^[[:space:]]*#' -e '^[[:space:]]*$' "$f" 2>/dev/null)
        [ "${n:-0}" -gt 0 ] 2>/dev/null && echo " -- authorized_keys: $n ключ(ей) у $u ($f) — СВОИ? лишние удали"
    done
    pgrep -x tcpdump >/dev/null && echo " -- tcpdump: пишет" || echo " -- tcpdump: НЕ пишет"
    ls /root/ad_backups/ 2>/dev/null | tail -3
}

case "${1:-}" in
    --lock) stage2 ;;
    --check) check ;;
    --dry) dry ;;
    "") stage1 ;;
    *) echo "использование: bash harden.sh [--dry|--lock|--check]"; exit 1 ;;
esac
