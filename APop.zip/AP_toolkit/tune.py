#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TUNE — одна кнопка подстройки ВСЕХ вводных комплекта.

Зачем: на игре вводные могут отличаться от плана (другая подсеть, другой
формат флага, другой порт сдачи, пароль не тот). Вместо того чтобы лазить
руками по файлам и что-то сломать — один скрипт меняет вводные ВЕЗДЕ:

  farm.json      — всё, что читает ферма (farm.py)
  settings.env   — всё, что читают bash-скрипты (harden.sh, tripwire.sh)

Запуск:
  python3 tune.py                # интерактивно: вопросы с текущими значениями
  python3 tune.py --show         # просто показать текущие вводные
  python3 tune.py --set my_team=7 --set default_pass=s3cret
                                 # точечно, без вопросов (можно несколько)

После изменения: python3 farm.py --sweep (проверка), bash tripwire.sh install
(канарейки перегенерируются под новый формат флага).

Ничего не требует, только стандартная библиотека.
"""
import json
import os
import re
import sys

TOOL_DIR = os.path.dirname(os.path.abspath(__file__))
FARM_JSON = os.path.join(TOOL_DIR, "farm.json")
SETTINGS_ENV = os.path.join(TOOL_DIR, "settings.env")

# Что вообще можно крутить: ключ -> (описание для человека, дефолт)
FIELDS = {
    "my_team":         ("номер НАШЕЙ команды (не брутим и не фармим себя)", 0),
    "first_team":      ("первый номер команды в сетке", 1),
    "last_team":       ("последний номер команды в сетке", 30),
    "subnet_template": ("шаблон IP вулнбокса, {t} = номер команды", "10.2.{t}.2"),
    "default_pass":    ("дефолтный пароль SSH (он одинаковый у всех команд)", "CHANGE-ME"),
    "default_users":   ("логины через запятую", "root,user,admin"),
    "team_token":      ("токен нашей команды для сдачи флагов", "PASTE-YOUR-TEAM-TOKEN"),
    "flag_regex":      ("регулярка флага", "[A-Z0-9]{31}="),
    "checksystem_host":("хост чек-системы (куда сдаём)", "10.10.10.10"),
    "checksystem_port":("порт сдачи", 31337),
    "protocol":        ("протокол сдачи: tcp или http", "tcp"),
    "http_flags_path": ("путь для http-сдачи", "/flags"),
    "ssh_port":        ("порт SSH на вулнбоксах", 22),
    "hunt_roots":      ("где на чужой коробке искать флаги, через ;", "/services /opt /srv /home /root /var/backups /flags"),
    "service_letters": ("первые буквы имён сервисов через запятую (в ForcAD флаг начинается с буквы сервиса — канарейки будут неотличимы)", ""),
    "decoy_dir":       ("где на НАШЕЙ коробке лежат канарейки-пустышки", "/flags-decoy"),
}


def load_farm():
    """Читаем farm.json (или дефолт, если его ещё нет)."""
    if os.path.exists(FARM_JSON):
        with open(FARM_JSON, "r", encoding="utf-8") as f:
            return json.load(f)
    from farm import DEFAULTS  # дефолты фермы как база
    return dict(DEFAULTS)


def save_farm(cfg):
    with open(FARM_JSON, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def current_values(cfg):
    """Собираем плоские значения для вопросов/показа из farm.json."""
    creds = cfg.get("creds") or []
    v = {
        "my_team": cfg.get("my_team", 0),
        "first_team": cfg.get("first_team", 1),
        "last_team": cfg.get("last_team", 30),
        "subnet_template": cfg.get("subnet_template", "10.2.{t}.2"),
        "default_pass": (creds[0].get("pass", "CHANGE-ME") if creds else "CHANGE-ME"),
        "default_users": ",".join(c.get("user", "") for c in creds) or "root,user,admin",
        "team_token": cfg.get("team_token", "PASTE-YOUR-TEAM-TOKEN"),
        "flag_regex": cfg.get("flag_regex", "[A-Z0-9]{31}="),
        "checksystem_host": cfg.get("checksystem_host", "10.10.10.10"),
        "checksystem_port": cfg.get("checksystem_port", 31337),
        "protocol": cfg.get("protocol", "tcp"),
        "http_flags_path": cfg.get("http_flags_path", "/flags"),
        "ssh_port": cfg.get("ssh_port", 22),
        "hunt_roots": " ".join(cfg.get("hunt_roots") or [""]),
        "service_letters": ",".join(cfg.get("service_letters") or []),
        "decoy_dir": cfg.get("decoy_dir", "/flags-decoy"),
    }
    return v


def apply_values(cfg, v):
    """Обратно: плоские значения -> структура farm.json."""
    cfg["my_team"] = int(v["my_team"])
    cfg["first_team"] = int(v["first_team"])
    cfg["last_team"] = int(v["last_team"])
    cfg["subnet_template"] = v["subnet_template"]
    users = [u.strip() for u in v["default_users"].split(",") if u.strip()]
    cfg["creds"] = [{"user": u, "pass": v["default_pass"]} for u in users]
    cfg["team_token"] = v["team_token"]
    cfg["flag_regex"] = v["flag_regex"]
    cfg["checksystem_host"] = v["checksystem_host"]
    cfg["checksystem_port"] = int(v["checksystem_port"])
    cfg["protocol"] = v["protocol"]
    cfg["http_flags_path"] = v["http_flags_path"]
    cfg["ssh_port"] = int(v["ssh_port"])
    cfg["hunt_roots"] = [p for p in v["hunt_roots"].split() if p]
    cfg["service_letters"] = [c.strip().upper()[:1] for c in v["service_letters"].split(",") if c.strip()]
    cfg["decoy_dir"] = v["decoy_dir"]
    return cfg


def validate(v):
    """Проверяем, что вводные осмысленные, ДО записи. Возвращает список проблем."""
    errs = []
    try:
        re.compile(v["flag_regex"])
    except re.error as e:
        errs.append("flag_regex не компилируется: %s" % e)
    try:
        int(v["my_team"]); int(v["first_team"]); int(v["last_team"])
    except ValueError:
        errs.append("номера команд должны быть числами")
    if v["protocol"] not in ("tcp", "http"):
        errs.append("protocol должен быть tcp или http")
    if v["default_pass"] == "CHANGE-ME":
        errs.append("default_pass — заглушка! впиши настоящий дефолтный пароль")
    if not v["default_users"].strip():
        errs.append("default_users пуст")
    return errs


def write_settings_env(v):
    """settings.env читают bash-скрипты (harden.sh, tripwire.sh) при старте."""
    lines = [
        "# генерируется tune.py — правь через python3 tune.py, руками не трогать",
        "# читается harden.sh и tripwire.sh",
        'AP_ROOT="%s"' % v.get("ap_root", "/root"),
        'DECOY="%s"' % v["decoy_dir"],
        "FLAG_REGEX='%s'" % v["flag_regex"],
        "SSH_PORT=\"%s\"" % v["ssh_port"],
        'SERVICE_LETTERS="%s"' % v.get("service_letters", ""),
    ]
    # Генератор канареек: поддерживаем главный формат [A-Z0-9]{31}=
    m = re.match(r"^\[A-Z0-9\]\{(\d+)\}=$", v["flag_regex"])
    if m:
        lines += ["CANARY_ALNUM_LEN=\"%s\"" % m.group(1), "CANARY_SUFFIX=\"=\""]
    else:
        lines += ["CANARY_ALNUM_LEN=\"31\"", "CANARY_SUFFIX=\"=\"",
                  "# ! регулярка нестандартная — канарейки генерируются по умолчанию;"]
    with open(SETTINGS_ENV, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def show():
    cfg = load_farm()
    v = current_values(cfg)
    print("ТЕКУЩИЕ ВВОДНЫЕ (farm.json + settings.env):")
    for k, (desc, _) in FIELDS.items():
        print("  %-18s %-44s  # %s" % (k, v.get(k, "?"), desc))
    print()
    print("Файлы: %s, %s" % (FARM_JSON, SETTINGS_ENV))


def interactive():
    cfg = load_farm()
    v = current_values(cfg)
    print("ПОДСТРОЙКА ВВОДНЫХ. Enter = оставить как есть.")
    print()
    for k, (desc, _) in FIELDS.items():
        cur = v.get(k, "")
        ans = input("  %s [%s]: " % (desc, cur)).strip()
        if ans:
            v[k] = ans
    errs = validate(v)
    if errs:
        print()
        for e in errs:
            print("ПРОБЛЕМА: %s" % e)
        print("Ничего не записано. Исправь и повтори.")
        return 1
    cfg = apply_values(cfg, v)
    save_farm(cfg)
    write_settings_env(v)
    print()
    print("Записано: %s" % FARM_JSON)
    print("Записано: %s" % SETTINGS_ENV)
    print()
    print("Проверка: python3 farm.py --sweep  (кто доступен с этими кредами)")
    print("Канарейки: sudo bash tripwire.sh install  (перегенерирует под формат)")
    return 0


def set_values(pairs):
    cfg = load_farm()
    v = current_values(cfg)
    for pair in pairs:
        if "=" not in pair:
            print("формат: --set ключ=значение (см. --show)")
            return 2
        k, val = pair.split("=", 1)
        if k not in FIELDS:
            print("неизвестный ключ %s (см. --show)" % k)
            return 2
        v[k] = val
    errs = validate(v)
    if errs:
        for e in errs:
            print("ПРОБЛЕМА: %s" % e)
        return 1
    cfg = apply_values(cfg, v)
    save_farm(cfg)
    write_settings_env(v)
    print("Обновлено. Текущее:")
    show()
    return 0


def main(argv=None):
    raw = list(sys.argv[1:] if argv is None else argv)

    # Нормализация: поддерживаем ТРИ формы —
    #   "--set my_team=7" (пробел, значение с =)
    #   "--set=my_team=7" (всё через равно)
    #   "--set my_team 7" (пробел, значение отдельно)
    args = []
    i = 0
    while i < len(raw):
        a = raw[i]
        if a == "--set":
            if i + 1 < len(raw) and "=" in raw[i + 1]:
                args.append("--set=" + raw[i + 1])
                i += 2
            elif i + 2 < len(raw):
                args.append("--set=" + raw[i + 1] + "=" + raw[i + 2])
                i += 3
            else:
                args.append(a)
                i += 1
            continue
        args.append(a)
        i += 1

    if "--show" in args:
        show()
        return 0
    sets = [a[6:] for a in args if a.startswith("--set=")]
    if sets:
        return set_values(sets)
    if "--help" in args or "-h" in args:
        print(__doc__)
        return 0
    if args:
        # есть аргументы, но мы их не поняли — НЕ падаем в интерактив
        # (интерактив ждёт ввод с клавиатуры и в скриптах виснет)
        print("Не понял аргументы: %s" % " ".join(args))
        print("Смотри: python3 tune.py --help   или   python3 tune.py --show")
        return 2
    return interactive()


if __name__ == "__main__":
    sys.exit(main())
