#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
АВТОПАТЧ — офлайн-анализатор сервиса Attack-Defense + ИИ (Cloudflare Workers AI).

Как пользоваться (коротко):
    python3 autopatch.py <путь_к_сервису_или_папке_с_сервисами> [--ai] [--deep]
    python3 autopatch.py                # интерактивный режим
    python3 autopatch.py --selftest     # проверка что тул живой
    python3 autopatch.py --clean-only    # только зачистка следов

Отчёт кладётся в OUTPUT/ рядом с тулом. Ничего вне своей папки не пишет.
"""
import argparse
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ap.ai import AIError, CFClient, QuotaExceeded, SYSTEM_PROMPT, build_case, clean_ai_output  # noqa: E402
from ap.cheat import print_short, render_cheatsheet  # noqa: E402
from ap.kb import KB  # noqa: E402
from ap.report import render_report, write_master  # noqa: E402
from ap.scan import Scanner  # noqa: E402
from ap.util import fmt_size, out_utf8, ts  # noqa: E402

TOOL_DIR = os.path.dirname(os.path.abspath(__file__))
KB_DIR = os.path.join(TOOL_DIR, "ap", "kb")
CONFIG = os.path.join(TOOL_DIR, "ap", "config.json")
OUTPUT = os.path.join(TOOL_DIR, "OUTPUT")

MARKER_NAMES = {"docker-compose.yml", "docker-compose.yaml", "Dockerfile", "requirements.txt",
                 "package.json", "Cargo.toml", "go.mod", "Makefile"}
CODE_EXTS = (".py", ".js", ".ts", ".go", ".rs", ".cpp", ".c", ".h", ".hpp", ".sol", ".proto")
GENERIC_SEGMENTS = {"services", "service", "task", "app", "src", "web", "backend", "main"}
DISCOVER_SKIP = {"sploits", "exploits", "checkers", "writeups", "scoreboard", "internal",
                 "geth", ".git", "node_modules", "front", "build", "dist", "target", "selftest",
                 "static", "assets"}


def _has_markers(d):
    """Есть ли в КАТАЛОГЕ (без рекурсии) маркер сервиса: код-файл или docker-конфиг."""
    try:
        for fn in os.listdir(d):
            if os.path.isfile(os.path.join(d, fn)):
                if os.path.splitext(fn)[1].lower() in CODE_EXTS or fn in MARKER_NAMES:
                    return True
    except OSError:
        pass
    return False


def _clean_name(segments):
    keep = [s for s in segments if s.lower() not in GENERIC_SEGMENTS]
    if not keep:
        return segments[-1] if segments else "service"
    return "-".join(keep)


def find_services(target):
    """Рекурсивное обнаружение сервисов: внешние каталоги с маркерами.

    Кейс «репо/папка со многими сервисами» и «сервис с вложенным task/»
    оба разбираются: берутся внешние помеченные каталоги; корень-оркестратор
    (compose на корне + ≥3 сервисов ниже) отбрасывается.
    """
    target = os.path.abspath(target)
    marked = []

    def walk(d, rel):
        if os.path.basename(d) in DISCOVER_SKIP and d != target:
            return
        if _has_markers(d):
            marked.append((d, rel))
        try:
            subs = sorted(x for x in os.listdir(d) if os.path.isdir(os.path.join(d, x)))
        except OSError:
            return
        for s in subs:
            if s in DISCOVER_SKIP or s.startswith("."):
                continue
            walk(os.path.join(d, s), rel + [s])

    walk(target, [])
    if not marked:
        return []

    def outermost():
        marked_set = {d for d, _ in marked}
        return [(d, rel) for d, rel in marked
                if not any(d != p and d.startswith(p + os.sep)
                           for p in marked_set)]

    out = outermost()
    # корень-оркестратор: сам помечен, но ниже ≥3 сервисов → корень отбросить
    if len(out) == 1 and out[0][0] == target and len(marked) >= 4:
        marked[:] = [(d, rel) for d, rel in marked if d != target]
        out = outermost()
    res = []
    for d, rel in out:
        segs = [s for s in rel if s] or [os.path.basename(target)]
        name = _clean_name(segs)
        if name.lower() in GENERIC_SEGMENTS:
            parent = os.path.basename(os.path.dirname(d))
            if parent and parent.lower() not in GENERIC_SEGMENTS and parent not in ("repos", "knowledge"):
                name = parent
        res.append((name, d))
    return res


def analyze_service(name, path, scanner, kb, client=None):
    print("  [scan] %s ..." % name)
    scan = scanner.scan_service(path)
    print("         файлов %d, строк ~%d, греп-находок %d" % (
        scan["n_files"], scan["n_lines"], len(scan["findings"])))
    matches = kb.match(scan)
    top = [m for m in matches if m["score"] >= 6][:3]
    if top:
        print("         база знаний: %s" % "; ".join(
            "%s (%d%%)" % (m["dossier"]["id"], int(m["confidence"] * 100)) for m in top))

    ai_section, ai_note, mode = None, None, "offline"
    if client is not None and client.available():
        mode = "online"
        case = build_case(name, scan, matches)
        messages = [{"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": case}]
        try:
            print("         ИИ: анализ через Cloudflare (может занять 1-3 мин)...")
            text, model, neurons = client.ask_cascade(messages)
            ai_section = clean_ai_output(text)
            ai_note = "модель %s, нейронов %.1f. %s" % (model, neurons, client.usage_report())
            print("         ИИ: готово (%s, %.0f нейронов)" % (model, neurons))
        except QuotaExceeded as e:
            ai_note = "ИИ отключён: %s. Работает офлайн-часть (грепы+база) — она не зависит от квоты." % e
            print("         ИИ: квота — %s" % e)
            mode = "offline"
        except AIError as e:
            ai_note = "ИИ недоступен (%s). Отчёт построен офлайн-частью." % e
            print("         ИИ: ошибка — %s" % e)

    md = render_report(name, scan, matches, ai_section=ai_section, ai_note=ai_note, mode=mode)
    out_dir = os.path.join(OUTPUT, "%s-%s" % (name.replace("/", "_"), ts()))
    os.makedirs(out_dir, exist_ok=True)
    rep = os.path.join(out_dir, "REPORT.md")
    with open(rep, "w", encoding="utf-8") as fh:
        fh.write(md)
    return name, scan, matches, rep


def clean_traces():
    """Зачистка: кэши питона, временные каталоги тула. Вне флешки ничего не трогаем."""
    removed = []
    for d in ("__pycache__",):
        p = os.path.join(TOOL_DIR, d)
        if os.path.isdir(p):
            shutil.rmtree(p, ignore_errors=True)
            removed.append(p)
    p = os.path.join(TOOL_DIR, "ap", "__pycache__")
    if os.path.isdir(p):
        shutil.rmtree(p, ignore_errors=True)
        removed.append(p)
    return removed


def wizard():
    print("=" * 60)
    print("  АВТОПАТЧ — анализатор сервисов Attack-Defense (InnoCTF Junior)")
    print("=" * 60)
    print("Раунд 2 мин, флаг живёт 10 мин — патчить быстро и по делу.")
    print("Отчёт появится в OUTPUT/ рядом с тулом. Вне своей папки не пишем.")
    print()
    print("Доставка тула (флешки запрещены, GitHub/GitLab разрешены):")
    print("  git clone <приватный репо с бандлом>  # репо готовим ДО игры")
    print("Первым делом: python3 autopatch.py --cheat  (SSH-пароли, инвентарь, бэкапы)")
    print()
    print("Как достать код сервиса с вулнбокса (10.2.<X>.2):")
    print("  scp -r user@10.2.<X>.2:/services ~/services   # потом путь к ~/services")
    print()
    target = input("Путь к сервису или папке с сервисами: ").strip().strip('"').strip("'")
    if not target:
        target = os.path.join(os.path.dirname(TOOL_DIR), "services")
    use_ai = input("Использовать ИИ Cloudflare? (нужен интернет с телефона; Enter = да, 'n' = офлайн): ").strip().lower()
    return target, use_ai != "n"


def selftest():
    """Мини-проверка движка на встроенном уязвимом примере."""
    sample_dir = os.path.join(TOOL_DIR, "selftest")
    scanner = Scanner(KB_DIR)
    kb = KB(KB_DIR)
    print("Досье в базе: %d" % len(kb.dossiers))
    scan = scanner.scan_service(sample_dir)
    print("Самотест: файлов %d, находок %d" % (scan["n_files"], len(scan["findings"])))
    classes = {f["class"] for f in scan["findings"]}
    print("Классы найдены: %s" % ", ".join(sorted(classes)))
    expect = {"SQLi", "CmdInjection", "HardcodedSecret", "IDOR"}
    ok = expect.issubset(classes)
    print("САМОТЕСТ %s" % ("ПРОЙДЕН" if ok else "ПРОВАЛЕН: нет классов %s" % (expect - classes)))
    return 0 if ok else 1


def main(argv=None):
    out_utf8()
    ap = argparse.ArgumentParser(description="АВТОПАТЧ: офлайн + ИИ анализ сервиса A/D")
    ap.add_argument("target", nargs="?", help="путь к сервису или папке сервисов")
    ap.add_argument("--ai", action="store_true", help="включить ИИ-анализ (Cloudflare)")
    ap.add_argument("--offline", action="store_true", help="только офлайн-часть")
    ap.add_argument("--out", default=None, help="куда класть отчёты (по умолчанию OUTPUT/)")
    ap.add_argument("--selftest", action="store_true", help="проверка движка")
    ap.add_argument("--clean-only", action="store_true", help="только зачистка следов")
    ap.add_argument("--wipe-self", action="store_true", help="УДАЛИТЬ тул полностью (после копирования отчётов)")
    ap.add_argument("--cheat", action="store_true", help="cheat-лист первых 40 минут (в консоль + OUTPUT)")
    args = ap.parse_args(argv)

    if args.selftest:
        return selftest()
    if args.cheat:
        os.makedirs(OUTPUT, exist_ok=True)
        p = os.path.join(OUTPUT, "CHEATSHEET.md")
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(render_cheatsheet())
        print_short()
        print()
        print("Полная версия записана: %s" % p)
        clean_traces()
        return 0
    if args.out:
        globals()["OUTPUT"] = os.path.abspath(args.out)
    if args.clean_only or args.wipe_self:
        removed = clean_traces()
        for r in removed:
            print("удалено: %s" % r)
        if args.wipe_self:
            shutil.rmtree(TOOL_DIR, ignore_errors=True)
            print("ТУЛ УДАЛЁН ПОЛНОСТЬЮ (отчёты забери из OUTPUT заранее!)")
        return 0

    target, use_ai = args.target, (not args.offline)
    if target is None:
        target, use_ai = wizard()
        print()
    if not os.path.isdir(target):
        print("Путь не найден: %s" % target)
        return 2

    services = find_services(target)
    if not services:
        print("По пути %s сервисов не найдено (нет .py/.js/.go/.cpp/docker-compose)." % target)
        return 2
    print("Найдено сервисов: %d" % len(services))
    for n, p in services:
        print("  - %s (%s)" % (n, p))
    print()

    scanner = Scanner(KB_DIR)
    kb = KB(KB_DIR)
    client = None
    if use_ai or args.ai:
        try:
            client = CFClient(CONFIG)
            if not client.available():
                print("ИИ: в config.json нет токена — работаем офлайн.\n")
                client = None
        except Exception as e:
            print("ИИ: config.json не читается (%s) — работаем офлайн.\n" % e)
            client = None

    reports = []
    for name, path in services:
        reports.append(analyze_service(name, path, scanner, kb, client))
        print()

    if len(reports) > 1:
        master = write_master(OUTPUT, reports)
        print("СВОДКА ПО ВСЕМ: %s" % master)
    print("ГОТОВО. Отчёты:")
    for name, _, _, rep in reports:
        print("  %s -> %s (%s)" % (name, rep, fmt_size(os.path.getsize(rep))))
    if client is not None:
        print(client.usage_report())
    clean_traces()
    print()
    print("Следы на этой машине: ничего не писалось вне папки тула;")
    print("кэш __pycache__ удалён. На вулнбоксе не запускали — следы там не появлялись.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
