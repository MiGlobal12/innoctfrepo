# -*- coding: utf-8 -*-
"""Генератор отчёта: подробная инструкция по патчам."""
import json
import os

from .kb import match_label
from .scan import SEV_RU, findings_summary

CHECKLIST = """## 6. Первые действия на вулнбоксе (строго по порядку)

Сетка: команда `10.2.<X>.0/24`, вулнбокс `10.2.<X>.2`; раунд 2 мин, флаг живёт 10 мин,
2 флага на уязвимость. attack_data: `http://10.10.10.10/api/client/attack_data`
(там видно, ЧТО у нас exploited — патчевать в первую очередь).

```bash
# 0. СМЕНИТЬ ДЕФОЛТНЫЕ ПАРОЛИ SSH (у всех команд они одинаковые!):
passwd && sudo passwd root
sudo sed -i 's/^#\\?PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
sudo systemctl restart ssh
# 1. Бэкап исходников ДО патчей:
cd /путь/к/сервисам && tar czf ~/ad_backups/services-$(date +%s).tar.gz .
git init . && git add -A && git commit -m "initial"
# 2. Трафик в запись с первой минуты:
tcpdump -i any -w /root/capture.pcap &
# 3. Пересборка и проверка после КАЖДОГО патча:
docker compose up -d --build && docker ps
# 4. Если чекер сломался — немедленный откат:
git checkout -- . && docker compose up -d --build
```
Правила: один баг = один патч = один коммит; не менять порты/пути/формат ответов;
не трогать схему БД; перед патчем git diff; после — проверка чекером и скорборд.
Полный cheat-лист первых 40 минут: `python3 autopatch.py --cheat`."""


def severity_badge(sev):
    return {
        "crit": "[!!! КРИТ]",
        "high": "[!! ВЫСОКО]",
        "med": "[! СРЕДНЕ]",
        "info": "[i]",
    }.get(sev, "[?]")


def render_report(name, scan, matches, ai_section=None, ai_note=None, mode="offline"):
    lines = []
    summ = findings_summary(scan["findings"])
    top_matches = [m for m in matches if m["score"] >= 6][:3]
    strong_matches = [m for m in matches if m["confidence"] >= 0.35][:2]

    lines.append("# АВТОПАТЧ-ОТЧЁТ: %s" % name)
    lines.append("")
    lines.append("- Путь: `%s`" % scan["root"])
    lines.append("- Файлов просканировано: %d (~%d строк)" % (scan["n_files"], scan["n_lines"]))
    if scan["stack"]:
        lines.append("- Стек: %s" % ", ".join(scan["stack"]))
    if scan["binaries"]:
        lines.append("- ELF-бинари (исходников нет): %s — анализируются по поведению/паттернам базы"
                     % ", ".join(scan["binaries"][:6]))
    lines.append("- Режим: %s" % ("офлайн (греп-паттерны + база знаний)" if mode == "offline" else "офлайн + ИИ (Cloudflare Workers AI)"))
    lines.append("")
    lines.append("## 1. СВОДКА УГРОЗ")
    lines.append("")
    lines.append("| Критичность | Находок |")
    lines.append("|---|---|")
    for sev in ("crit", "high", "med", "info"):
        if summ.get(sev):
            lines.append("| %s | %d |" % (SEV_RU[sev], summ[sev]))
    if top_matches:
        lines.append("")
        lines.append("**Совпадение с известными сервисами:** " + "; ".join(
            "%s (%s, %d%%)" % (m["dossier"]["title"], m["dossier"]["source"], int(m["confidence"] * 100))
            for m in top_matches))
    if scan["env_secrets"]:
        lines.append("")
        lines.append("**Секреты в .env/конфигах (%d):** проверить, что они НЕ статичные/одинаковые у всех команд." % len(scan["env_secrets"]))
    lines.append("")

    # --- 2. Приоритетные патчи ---------------------------------------
    lines.append("## 2. ПАТЧИ ПО ПРИОРИТЕТУ")
    lines.append("")
    wrote = _write_dossier_patches(lines, strong_matches)
    wrote += _write_scanner_patches(lines, scan, start_num=wrote)
    if wrote == 0:
        lines.append("_Греп-паттерны и база не дали конкретики — см. раздел 4 и 5 (вручную)._")

    # --- 3. Досье -----------------------------------------------------
    if top_matches:
        lines.append("")
        lines.append("## 3. ДОСЬЕ ИЗВЕСТНЫХ СЕРВИСОВ (вероятные предки)")
        lines.append("")
        for m in top_matches:
            d = m["dossier"]
            lines.append("### %s — %s (%s, совпадение %d%%: %s)" % (
                d["title"], match_label(m["confidence"]), d["source"],
                int(m["confidence"] * 100), "; ".join(m["matched"][:6])))
            lines.append("")
            lines.append("- Стек: %s" % d["stack"])
            lines.append("- Где флаг: %s" % d["flag_location"])
            lines.append("- Чекер: %s" % d["checker_notes"])
            for v in d["vulns"]:
                lines.append("")
                lines.append("#### [%s] %s — %s" % (v["class"], v["id"], v["where"]))
                lines.append("- **Что:** %s" % v["what"])
                lines.append("- **Как крадут флаг:** %s" % v["exploit"])
                lines.append("- **Патч:**")
                lines.append("")
                lines.append("```")
                for chunk in v["patch"].split("\n"):
                    lines.append(chunk)
                lines.append("```")
                lines.append("- **Почему чекер жив:** %s" % v["checker_safe"])
            lines.append("")

    # --- 4. Все находки грепов ---------------------------------------
    lines.append("")
    lines.append("## 4. ВСЕ НАХОДКИ ГРЕП-ПАТТЕРНОВ (%d)" % len(scan["findings"]))
    lines.append("")
    if scan["findings"]:
        lines.append("| № | Сев | Класс | Файл:строка | Что увидел греп |")
        lines.append("|---|---|---|---|---|")
        for i, f in enumerate(scan["findings"][:120], 1):
            esc = f["code"].replace("|", "\\|")
            lines.append("| %d | %s | %s | `%s:%d` | %s |" % (
                i, severity_badge(f["sev"]), f["class"], f["file"], f["line"], esc))
        if len(scan["findings"]) > 120:
            lines.append("")
            lines.append("_(показаны первые 120 из %d)_" % len(scan["findings"]))
    else:
        lines.append("Чисто. Либо код не читается как текст (ELF), либо паттерны не сработали.")

    # --- 5. Маршруты и подозрительные места --------------------------
    lines.append("")
    lines.append("## 5. ПОВЕРХНОСТЬ АТАКИ")
    if scan["routes"]:
        lines.append("")
        lines.append("Найдено маршрутов/ручек: %d. Проверить на каждом: авторизацию, владельца данных, валидацию ввода." % len(scan["routes"]))
        lines.append("")
        lines.append("| Файл | Роут |")
        lines.append("|---|---|")
        for rel, path in scan["routes"][:60]:
            lines.append("| `%s` | `%s` |" % (rel, path))
    if scan["env_secrets"]:
        lines.append("")
        lines.append("### Секреты в конфигах")
        for s in scan["env_secrets"]:
            lines.append("- `%s:%d` **%s** = ...%s (проверить: не одинаков ли у всех команд!)" % (
                s["file"], s["line"], s["key"], s["value_tail"]))
    if scan["compose"]:
        lines.append("")
        lines.append("### Docker-конфиги: %s" % ", ".join(scan["compose"].keys()))

    # --- 5b. AI section ----------------------------------------------
    if ai_section or ai_note:
        lines.append("")
        lines.append("## 5-ИИ. АНАЛИЗ ИИ (Cloudflare Workers AI)")
        if ai_note:
            lines.append("")
            lines.append("_%s_" % ai_note)
        if ai_section:
            lines.append("")
            lines.append(ai_section)

    # --- 6. Чеклист --------------------------------------------------
    lines.append("")
    lines.append(CHECKLIST)
    lines.append("")
    lines.append("---")
    lines.append("_Сгенерировано autopatch (офлайн-паттерны + досье 15 сервисов C4T BuT S4D / InnoCTF 2022). "
                 "Патчи перед применением читай глазами: один баг = один патч._")
    return "\n".join(lines)


def _write_dossier_patches(lines, top_matches):
    n = 0
    for m in top_matches:
        d = m["dossier"]
        for v in d["vulns"]:
            n += 1
            lines.append("### ПАТЧ %d [%s] %s" % (n, v["class"], v["id"]))
            lines.append("")
            lines.append("**Где:** `%s`" % v["where"])
            lines.append("")
            lines.append("**Патч (БЫЛО → СТАЛО):**")
            lines.append("")
            lines.append("```")
            lines.append(v["patch"])
            lines.append("```")
            lines.append("")
            lines.append("**Почему чекер жив:** %s" % v["checker_safe"])
            lines.append("**Проверка:** воспроизвести руками (как в поле «Как крадут флаг»), затем прогнать чекер, затем скорборд.")
            lines.append("**Откат:** `git checkout -- . && docker compose up -d --build`")
            lines.append("")
    return n


def _write_scanner_patches(lines, scan, start_num=0):
    """Top критичных греп-находок с рецептом из патчбука."""
    n = start_num
    seen = set()
    for f in scan["findings"]:
        if f["sev"] not in ("crit", "high") or n - start_num >= 12:
            continue
        key = (f["class"], f["file"], f["hint"])
        if key in seen:
            continue
        seen.add(key)
        n += 1
        lines.append("### ПАТЧ %d [%s] %s — `%s:%d`" % (n, f["class"], f["hint"], f["file"], f["line"]))
        lines.append("")
        lines.append("```")
        lines.append(f["code"])
        lines.append("```")
        if f["fix"]:
            lines.append("")
            lines.append("**Рецепт:** %s" % f["fix"])
            lines.append("")
    return n




def write_master(out_dir, reports):
    """Сводный индекс по всем сервисам."""
    lines = ["# СВОДКА ПО ВСЕМ СЕРВИСАМ", ""]
    lines.append("| Сервис | Файлов | КРИТ | ВЫСОКО | База знаний | Отчёт |")
    lines.append("|---|---|---|---|---|---|")
    for name, scan, matches, path in reports:
        summ = findings_summary(scan["findings"])
        top = matches[0] if matches and matches[0]["score"] >= 6 else None
        base = ("%s (%d%%)" % (top["dossier"]["id"], int(top["confidence"] * 100))) if top else "—"
        lines.append("| %s | %d | %d | %d | %s | %s |" % (
            name, scan["n_files"], summ.get("crit", 0), summ.get("high", 0), base, os.path.basename(path)))
    p = os.path.join(out_dir, "00_SVODKA.md")
    with open(p, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))
    return p
