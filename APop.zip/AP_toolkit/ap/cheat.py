# -*- coding: utf-8 -*-
"""Cheat-лист первых 40 минут: защита вулнбокса под реалии InnoCTF Junior.

Печатается в консоль и пишется в OUTPUT/CHEATSHEET.md. Полностью офлайн.
"""

NETWORK = """## Сетка (с открытия)

| Что | Значение |
|---|---|
| Подсеть команды | `10.2.<X>.0/24` (X — номер твоей команды) |
| Твой vulnbox | `10.2.<X>.2` |
| attack_data API | `http://10.10.10.10/api/client/attack_data` |
| Сертификат | `http://10.10.10.10:8080/cert` |
| Раунд | 2 минуты |
| Жизнь флага | 10 минут |
| Флагов на одну уязвимость | 2 |

Прочее: iptables/netfilter на месте; весь трафик шифруется (TLS у всех);
на внешку со сторонних сайтов доступны только GET (POST запрещён) —
экфильтрация только GET/DNS-каналами; VPN нет; бродкасты работают;
SSH у команд по дефолтным паролям (если у тебя пароль «admin» — он же у всех).
Сеть между командами открывается в ~10:40.
"""

HARDEN = """## 0-я минута: закрыть дефолтный SSH (самое важное!)

У ВСЕХ команд одинаковые дефолтные креды. Пока не сменил — любой зайдёт и
снесёт твои сервисы («можно в 10:40 зайти и удалить всё» — так и будет).

```bash
# На вулнбоксе (Ubuntu 26 server) сразу после выдачи:
passwd                      # сменить пароль СВОЕГО юзера (не дефолт!)
sudo passwd root            # и рут тоже
# сменить пароли ВСЕХ учёток с шеллом:
cut -d: -f1,7 /etc/passwd | grep -E 'sh$' | cut -d: -f1 | xargs -I{} sudo passwd {}

# Добавить свой ключ и закрыть парольный вход (ключи держать на своей Kali):
mkdir -p ~/.ssh && chmod 700 ~/.ssh
# с Kali: ssh-copy-id user@10.2.<X>.2   (пароль уже сменён)
sudo sed -i 's/^#\\?PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
sudo sed -i 's/^#\\?PermitRootLogin.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
sudo systemctl restart ssh
# проверить из Kali: ssh user@10.2.<X>.2 (по ключу заходит, по паролю — нет)

# Никому не давать новый пароль. Проверить, что не осталось дефолт-кредов:
grep -rniE 'password|passwd' /etc/shadow 2>/dev/null | head -5   # под sudo
sudo cat /etc/ssh/sshd_config | grep -Ei 'password|root'
```

## 5-я минута: инвентарь — где вообще живут сервисы

Сервисы лежат на машине локально. Кроме docker-compose бывают и другие
запускалки (ответ на вопрос «что кроме докера»):

```bash
docker ps -a; docker compose ls; ls -la /services 2>/dev/null   # основной путь
systemctl list-units --type=service --state=running              # systemd-юниты
sudo ss -tlnp                                                   # что слушает порты (главное!)
ps aux --sort=-%cpu | head -20                                  # голые процессы
crontab -l; sudo ls /etc/cron*                                  # кроном запущенное
ls /etc/supervisor* 2>/dev/null; supervisorctl status 2>/dev/null # supervisor
tmux ls; screen -ls                                             # в tmux/screen поднятое
```

Правило: каждый слушающий порт = ровно один сервис = знать его каталог.

## 10-я минута: бэкапы и трекинг

```bash
sudo tar czf /root/ad_backups/services-$(date +%s).tar.gz -C /services .
cd /services/<svc> && git init . && git add -A && git commit -m initial   # в каждом сервисе
# трафик в запись с первой минуты (кто нас бьёт — видно в pcap):
sudo tcpdump -i any -w /root/capture.pcap &
```

## Патчи: темп игры

Раунд 2 минуты, флаг живёт 10 минут, на одну уязвимость 2 флага — значит
один незапатченный баг ≈ минус SLA каждые 2 минуты. Приоритет:

1. Утечка чужих данных/флагов (IDOR, SQLi, auth bypass) — патчить первым.
2. RCE/инъекция команд — вторым.
3. DoS-баги — по остаточному принципу (форфа меньше).
4. Один баг = один патч = один коммит: `git diff` → `docker compose up -d --build` → скорборд.
5. Чекер сломался — `git checkout -- . && docker compose up -d --build` (у нас бэкапы!).

## Атака (после 10:40, когда откроют сеть)

Бродкасты работают, у чужих SSH те же дефолтные пароли:
`nmap -sU -p 31337 10.2.<Y>.0/24` не нужен — просто перебор команд 10.2.<Y>.2 по дефолт-кредам.
Но сначала: свой вулнбокс защищён? Тогда чужие по остаточному времени.
attack_data (`10.10.10.10/api/client/attack_data`) показывает, кто и что exploited —
свои дырки видно по чужим атакам: сразу лезть в тот файл и патчить.
"""

WARNING = """ПОРЯДОК НЕ МЕНЯТЬ: SSH-пароли → инвентарь → бэкапы → автопатчер по сервисам.
Если в 10:40 у тебя всё ещё дефолтный пароль — вас снесут первыми.
"""


def render_cheatsheet():
    return "\n\n".join([
        "# CHEATSHEET: первые 40 минут InnoCTF Junior A/D",
        "",
        WARNING,
        NETWORK,
        HARDEN,
        "---",
        "_Сгенерировано autopatch --cheat (офлайн)._",
    ])


def print_short():
    print(WARNING.strip())
    print()
    for line in NETWORK.split("\n"):
        if line.startswith(("| Что", "|---", "| Подсеть", "| Твой", "| attack", "| Сертификат", "| Раунд", "| Жизнь", "| Флагов")):
            print(line)
    print()
    print("Полная версия: python3 autopatch.py --cheat  → OUTPUT/CHEATSHEET.md")
    print("Шаги: 1) сменить все пароли SSH  2) sudo ss -tlnp — что слушает")
    print("      3) бэкапы tar+git в каждый сервис  4) автопатчер по сервисам")
