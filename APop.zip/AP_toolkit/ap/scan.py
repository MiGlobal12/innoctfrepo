# -*- coding: utf-8 -*-
"""Сканер: греп-паттерны патчбука, инвентарь, маршруты, стек."""
import json
import os
import re

from .util import read_text, walk_files, is_binary

SEV_ORDER = {"crit": 0, "high": 1, "med": 2, "info": 3}
SEV_RU = {"crit": "КРИТ", "high": "ВЫСОКО", "med": "СРЕДНЕ", "info": "ИНФО"}


class Scanner(object):
    def __init__(self, kb_dir):
        with open(os.path.join(kb_dir, "patchbook.json"), "r", encoding="utf-8") as f:
            self.book = json.load(f)
        self.patterns = []
        for p in self.book["patterns"]:
            try:
                p["_re"] = re.compile(p["re"])
                self.patterns.append(p)
            except re.error:
                continue
        self.stack_markers = self.book.get("stack_markers", {})

    # ------------------------------------------------------------------
    def scan_service(self, root):
        """Полный офлайн-скан каталога-сервиса. Возвращает dict-отчёт."""
        root = os.path.abspath(root)
        files = walk_files(root)
        texts = {}
        binaries = []
        for rel, p, sz in files:
            if is_binary(p):
                binaries.append(rel)
                continue
            t = read_text(p)
            if t is not None:
                texts[rel] = t

        findings = self._grep(texts)
        routes = self._routes(texts)
        stack = self._stack(texts, binaries, files)
        env_secrets = self._env(texts)
        compose = self._compose(files, texts)

        return {
            "root": root,
            "files": [(r, s) for r, _, s in files],
            "n_files": len(files),
            "n_lines": sum(t.count("\n") for t in texts.values()),
            "texts": texts,
            "binaries": binaries,
            "findings": findings,
            "routes": routes,
            "stack": stack,
            "env_secrets": env_secrets,
            "compose": compose,
        }

    # ------------------------------------------------------------------
    def _grep(self, texts):
        out = []
        for rel, text in texts.items():
            if rel.endswith((".min.js", ".map", ".css")):
                continue
            lines = text.split("\n")
            for p in self.patterns:
                if p["_re"] is None:
                    continue
                try:
                    for m in p["_re"].finditer(text):
                        line_no = text.count("\n", 0, m.start()) + 1
                        if line_no - 1 >= len(lines):
                            continue
                        snippet = lines[line_no - 1].strip()[:160]
                        # отсекаем шаблоны для языков, не подходящих файлу
                        if not self._lang_ok(p, rel):
                            continue
                        out.append({
                            "pattern": p["id"],
                            "class": p["class"],
                            "sev": p["sev"],
                            "file": rel,
                            "line": line_no,
                            "code": snippet,
                            "hint": p.get("hint", ""),
                            "fix": p.get("fix", ""),
                        })
                except Exception:
                    continue
        out.sort(key=lambda f: (SEV_ORDER.get(f["sev"], 9), f["class"], f["file"], f["line"]))
        return out

    def _lang_ok(self, p, rel):
        langs = p.get("langs", ["any"])
        if "any" in langs:
            return True
        ext = os.path.splitext(rel)[1].lower()
        if rel.endswith("Dockerfile") or "docker-compose" in rel:
            cur = "yaml"
        elif ext in (".py",):
            cur = "py"
        elif ext in (".js", ".mjs", ".ts", ".tsx", ".jsx", ".hbs", ".ejs", ".php"):
            cur = "js"
        elif ext in (".cpp", ".cc", ".cxx", ".c", ".h", ".hpp", ".sh"):
            cur = "cpp"
        elif ext == ".go":
            cur = "go"
        elif ext == ".rs":
            cur = "rust"
        elif ext == ".sol":
            cur = "solidity"
        else:
            cur = "text"
        return cur in langs

    def _routes(self, texts):
        routes = []
        rx = re.compile(r"@app\.route\(\s*['\"]([^'\"]+)['\"]|CROW_ROUTE\([^)]*['\"]([^'\"]+)['\"]"
                        r"|app\.(get|post|put|delete|patch)\(\s*['\"]([^'\"]+)['\"]"
                        r"|router\.(get|post|put|delete)\(\s*['\"]([^'\"]+)['\"]")
        for rel, text in texts.items():
            if not rel.endswith((".py", ".js", ".ts", ".cpp", ".go")):
                continue
            for m in rx.finditer(text):
                path = next(g for g in m.groups() if g)
                routes.append((rel, path))
        return routes

    def _stack(self, texts, binaries, files):
        joined = "\n".join(texts.values())[:400000]
        found = []
        for name, markers in self.stack_markers.items():
            hits = sum(joined.count(mk) for mk in markers)
            if hits > 0:
                found.append((hits, name))
        found.sort(reverse=True)
        stack = [n for _, n in found[:5]]
        if any(b.endswith((".app", "app", "station", "check_pass")) or "app/app" in b for b in binaries):
            stack.append("elf-бинари (не исходник)")
        if any(rel.endswith(".sol") for rel, _, _ in files):
            stack.append("solidity-контракт")
        if any("grpc" in rel or rel.endswith(".proto") for rel, _, _ in files):
            stack.append("grpc/proto")
        return stack

    def _env(self, texts):
        secrets = []
        rx = re.compile(r"^([A-Z_0-9]*(KEY|SECRET|PASS|TOKEN|SALT)[A-Z_0-9]*)\s*=\s*(.+)$", re.I)
        for rel, text in texts.items():
            base = os.path.basename(rel).lower()
            if not (base.endswith(".env") or base == "app.conf" or ".env" in rel or "config" in base):
                continue
            for i, line in enumerate(text.split("\n"), 1):
                m = rx.match(line.strip())
                if m:
                    val = m.group(3).strip()
                    if val and not val.startswith("${"):
                        secrets.append({"file": rel, "line": i, "key": m.group(1), "value_tail": val[-6:]})
        return secrets

    def _compose(self, files, texts):
        info = {}
        for rel, text in texts.items():
            if "docker-compose" in rel or rel.endswith("Dockerfile"):
                info[rel] = len(text.split("\n"))
        return info


def findings_summary(findings):
    d = {}
    for f in findings:
        k = f["sev"]
        d[k] = d.get(k, 0) + 1
    return d
