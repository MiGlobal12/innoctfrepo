# -*- coding: utf-8 -*-
"""Вспомогательные функции: файлы, обфускация токена, печать."""
import base64
import io
import os
import re
import sys
import time

SKIP_DIRS = {
    "node_modules", ".git", ".hg", ".svn", "__pycache__", ".mypy_cache",
    "venv", ".venv", "env", "build", "dist", "target", "vendor", "deps",
    ".idea", ".vscode", "tmp", "cache", ".cache", "logs", "logs.sh",
}
TEXT_EXTS = {
    ".py", ".js", ".mjs", ".ts", ".tsx", ".jsx", ".json", ".yml", ".yaml",
    ".conf", ".ini", ".env", ".toml", ".cfg", ".hbs", ".ejs", ".php",
    ".cpp", ".cc", ".cxx", ".c", ".h", ".hpp", ".go", ".rs", ".sol",
    ".proto", ".sql", ".sh", ".bat", ".txt", ".md", ".html", ".css",
    ".cs", ".s", ".pl", ".rb", ".pyx", ".wasm", ".Dockerfile", ".example", ".sample", "",
}
MAX_FILE = 3 * 1024 * 1024  # 3 МБ на файл
ASSET_RX = re.compile(
    r"^(bootstrap|jquery|popper|moment|lodash|underscore|chart\.js|chart|leaflet|"
    r"vue|react|react-dom|angular|fontawesome|materialize|bulma|sweetalert|swiper|"
    r"aos|socket\.io|d3|three|axios|normalize)", re.I)


def _is_asset(fn):
    return fn.endswith((".min.js", ".min.css", ".map")) or ASSET_RX.match(fn)


def out_utf8():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def walk_files(root, max_files=4000):
    """Все текстовые файлы под root (без мусорных каталогов). Возвращает [(relpath, abspath, size)]."""
    res = []
    root = os.path.abspath(root)
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".git")]
        for fn in filenames:
            if _is_asset(fn):
                continue
            ext = os.path.splitext(fn)[1].lower()
            if fn == "Dockerfile" or fn == "docker-compose.yml":
                ext = ".txt"
            if ext not in TEXT_EXTS and not fn.startswith("docker-compose"):
                continue
            p = os.path.join(dirpath, fn)
            try:
                sz = os.path.getsize(p)
            except OSError:
                continue
            if sz > MAX_FILE:
                continue
            rel = os.path.relpath(p, root)
            res.append((rel, p, sz))
            if len(res) >= max_files:
                return res
    return res


def read_text(path):
    try:
        with io.open(path, "rb") as f:
            data = f.read()
        if b"\x00" in data[:4096]:
            return None  # бинарник
        return data.decode("utf-8", "replace")
    except OSError:
        return None


def is_binary(path):
    try:
        with io.open(path, "rb") as f:
            head = f.read(4096)
        return b"\x00" in head
    except OSError:
        return True


def ts():
    return time.strftime("%Y%m%d-%H%M%S")


def xor_b64(s, key=b"AP-k-e-y-2026!!"):
    """Лёгкая обфускация: XOR + base64 (защита от случайного grep флешки)."""
    raw = s.encode("utf-8")
    x = bytes(b ^ key[i % len(key)] for i, b in enumerate(raw))
    return base64.urlsafe_b64encode(x).decode("ascii")


def deobfuscate(s, key=b"AP-k-e-y-2026!!"):
    try:
        x = base64.urlsafe_b64decode(s.encode("ascii"))
        raw = bytes(b ^ key[i % len(key)] for i, b in enumerate(x))
        return raw.decode("utf-8")
    except Exception:
        return ""


def fmt_size(n):
    for unit in ["Б", "КБ", "МБ"]:
        if n < 1024:
            return "%d %s" % (n, unit)
        n //= 1024
    return "%d ГБ" % n
