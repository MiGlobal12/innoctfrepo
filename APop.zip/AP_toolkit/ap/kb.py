# -*- coding: utf-8 -*-
"""База знаний: досье известных сервисов + матчинг по сигнатурам."""
import json
import os


class KB(object):
    def __init__(self, kb_dir):
        self.dossiers = []
        ddir = os.path.join(kb_dir, "dossiers")
        if os.path.isdir(ddir):
            for fn in sorted(os.listdir(ddir)):
                if fn.endswith(".json"):
                    try:
                        with open(os.path.join(ddir, fn), "r", encoding="utf-8") as f:
                            self.dossiers.append(json.load(f))
                    except Exception:
                        continue

    def match(self, scan):
        """Матчинг отсканированного сервиса с досье.

        Скор: 2 за совпавший файл-сигнатуру, 3 за найденную строку-сигнатуру.
        Возвращает список {dossier, score, confidence, matched}.
        """
        rels = [r for r, _ in scan["files"]]
        rels_lower = [r.lower() for r in rels]
        bases = {os.path.basename(r).lower() for r in rels}
        texts = list(scan["texts"].values())

        def has_str(ss):
            return any(ss in t for t in texts)

        results = []
        for d in self.dossiers:
            total = 0
            got = 0
            matched = []
            for sf in d.get("signature_files", []):
                total += 2
                sf_l = sf.lower()
                base_l = os.path.basename(sf_l)
                hit = any(base_l in b for b in bases) or any(
                    sf_l in rl or os.path.basename(sf_l) in rl.split("/")
                    for rl in rels_lower
                )
                if hit:
                    got += 2
                    matched.append("файл: " + sf)
            for ss in d.get("signature_strings", []):
                total += 3
                if has_str(ss):
                    got += 3
                    matched.append("строка: " + ss)
            if total == 0:
                continue
            conf = got / total
            if got > 0:
                results.append({
                    "dossier": d,
                    "score": got,
                    "confidence": conf,
                    "matched": matched,
                })
        results.sort(key=lambda x: x["score"], reverse=True)
        return results

    @staticmethod
    def vuln_text(d, vuln):
        return d["vulns"]


def match_label(conf):
    if conf >= 0.5:
        return "СИЛЬНОЕ СОВПАДЕНИЕ"
    if conf >= 0.3:
        return "ВЕРОЯТНОЕ СОВПАДЕНИЕ"
    return "СЛАБОЕ СОВПАДЕНИЕ"
