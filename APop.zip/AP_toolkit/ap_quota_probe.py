# -*- coding: utf-8 -*-
"""Микро-зонд квоты Cloudflare Workers AI (копейки, ~0 нейронов при ошибке 4006).

Зачем: утром дня игры убедиться, что квота сбросилась (03:00 МСК), НЕ тратя её.
Пока квота исчерпана — зонд бесплатен; после сброса стоит доли нейрона.

Запуск из корня тулкита:  python3 ap_quota_probe.py
Ответ:
  QUOTA_OK neurons=N   — квота жива, N нейронов потратил сам зонд (это нормально)
  STILL_BLOCKED ...    — квота ещё не сбросилась, ИИ-слой уйдёт в офлайн-режим
"""
import json
import os
import urllib.error
import urllib.request

# config.json лежит рядом с этим скриптом — работает с любого места запуска
HERE = os.path.dirname(os.path.abspath(__file__))
cfg = json.load(open(os.path.join(HERE, "ap", "config.json"), encoding="utf-8"))

# Токен лежит в config.json в обфусцированном виде; распаковываем тем же
# алгоритмом, что и весь тул (ap/util.py), чтобы не светить токен в открытом виде
import sys
sys.path.insert(0, HERE)
from ap.util import deobfuscate

token = deobfuscate(cfg["token_obf"])
if not token:
    print("NO_TOKEN: в ap/config.json токены пустые (публичная копия?). "
          "Вставь свой токен: python3 token_setup.py cfut_...")
    sys.exit(0)
base = "https://api.cloudflare.com/client/v4/accounts/%s/ai/run/" % cfg["account_id"]
model = cfg["models"][0]  # первая модель каскада (gpt-oss-120b)

body = json.dumps({
    "messages": [{"role": "user", "content": "one word: PONG"}],
    "max_tokens": 5,  # микро-запрос: минимально возможный расход
}).encode("utf-8")

req = urllib.request.Request(base + model, data=body, method="POST")
req.add_header("Authorization", "Bearer " + token)
req.add_header("Content-Type", "application/json")
try:
    with urllib.request.urlopen(req, timeout=90) as r:
        data = json.loads(r.read().decode("utf-8", "replace"))
    res = data.get("result") or {}
    n = (res.get("usage") or {}).get("neurons")
    print("QUOTA_OK neurons=%s" % n)
except urllib.error.HTTPError as e:
    raw = e.read().decode("utf-8", "replace")
    print("STILL_BLOCKED HTTP %s %s" % (e.code, raw[:120]))
