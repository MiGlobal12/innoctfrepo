@echo off
rem ============================================================
rem  АВТОПАТЧ — запуск одним кликом (Windows)
rem  Отчёт появится в OUTPUT\ на этой флешке.
rem ============================================================
chcp 65001 >nul 2>&1
setlocal
cd /d "%~dp0"
set HISTFILE=
set PYTHONIOENCODING=utf-8

where py >nul 2>&1
if %errorlevel%==0 (
    py -3 autopatch.py %*
    goto :done
)
where python >nul 2>&1
if %errorlevel%==0 (
    python autopatch.py %*
    goto :done
)
echo Python не найден! Поставь Python 3 (python.org) или запусти на телефоне/вулнбоксе:
echo   run.sh
pause

:done
if "%1"=="" pause
endlocal
