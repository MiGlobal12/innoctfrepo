#!/usr/bin/env bash
# ============================================================
#  АВТОПАТЧ — запуск одним кликом (Linux/Mac/вулнбокс)
#  Отчёт появится в OUTPUT/ на этой флешке.
#  HISTFILE=/dev/null — команды не попадают в history.
# ============================================================
cd "$(dirname "$0")"
export HISTFILE=/dev/null
export PYTHONIOENCODING=utf-8

PY=""
if command -v python3 >/dev/null 2>&1; then PY=python3
elif command -v python >/dev/null 2>&1; then PY=python
else echo "python3 не найден"; exit 1; fi

"$PY" autopatch.py "$@"
