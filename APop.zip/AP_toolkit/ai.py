# -*- coding: utf-8 -*-
"""Клиент Cloudflare Workers AI: каскад моделей, счётчик нейронов, деградация.

Только стандартная библиотека (urllib) — работает на любом Python 3.8+
без pip, на вулнбоксе и на ноуте с флешки.
"""
import json
import os
import re
import urllib.error
import urllib.request

from .util import deobfuscate


class QuotaExceeded(Exception):
    pass


class AIError(Exception):
    pass


class CFClient(object):
    def __init__(self, config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            self.cfg = json.load(f)
        self.tokens = [t for t in (
            deobfuscate(self.cfg.get("token_obf", "")),
            deobfuscate(self.cfg.get("token2_obf", ""))) if t]
        self.token_idx = 0
        self.account = self.cfg.get("account_id", "")
        self.base = "https://api.cloudflare.com/client/v4/accounts/%s/ai/run/" % self.account
        self.budget = float(self.cfg.get("neuron_budget", 9000))
        self.used = 0.0
        self.models = self.cfg.get("models", [])
        self.timeout = int(self.cfg.get("timeout_sec", 120))

    # ------------------------------------------------------------------
    def available(self):
        return bool(self.tokens and self.account)

    # ------------------------------------------------------------------
    @staticmethod
    def _classify_http_error(e_code, raw):
        """Разбор ошибки HTTP → (тип, понятное сообщение по-русски).
        Типы: quota (квота), deprecated (модель устарела), paid (нужен платный
        план), auth (токен плохой), other. Это позволяет каскаду сразу понять,
        стоит ли пробовать следующую модель или падать целиком."""
        if "4006" in raw or "daily free allocation" in raw:
            return "quota", "квота нейронов на сегодня исчерпана"
        if "5028" in raw or "deprecated" in raw.lower():
            return "deprecated", "модель устарела (выведена из каталога CF)"
        if "not available on the Workers Free plan" in raw:
            return "paid", "модель доступна только на платном плане CF"
        if e_code in (401, 403) or "Authentication" in raw or "authorization" in raw:
            return "auth", "токен отклонён"
        return "other", raw[:160]

    def chat(self, model, messages, max_tokens=6000):
        """Один вызов модели. Возвращает (text, neurons_used).
        При auth-ошибке переключается на запасной токен и повторяет.
        Устаревшие/платные модели и квота НЕ ретраятся — их видно сразу."""
        last_auth = None
        for attempt in range(max(1, len(self.tokens))):
            token = self.tokens[min(self.token_idx, len(self.tokens) - 1)]
            body = json.dumps({
                "messages": messages,
                "max_tokens": max_tokens,
            }).encode("utf-8")
            req = urllib.request.Request(self.base + model, data=body, method="POST")
            req.add_header("Authorization", "Bearer " + token)
            req.add_header("Content-Type", "application/json")
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    data = json.loads(r.read().decode("utf-8", "replace"))
            except urllib.error.HTTPError as e:
                raw = b""
                try:
                    raw = e.read().decode("utf-8", "replace")
                except Exception:
                    pass
                etype, human = self._classify_http_error(e.code, raw)
                if etype == "quota":
                    raise QuotaExceeded(human)
                if etype == "auth" and self.token_idx < len(self.tokens) - 1:
                    last_auth = raw[:160]
                    self.token_idx += 1  # запасной токен
                    continue
                # deprecated / paid / прочее — причина в модели, не в токене:
                # каскад просто возьмёт следующую модель.
                raise AIError("%s (%s: HTTP %s)" % (human, model.split("/")[-1], e.code))
            except (urllib.error.URLError, OSError) as e:
                raise AIError(
                    "сеть: %s (подсказка: на площадке на сторонние сайты разрешён "
                    "только GET — POST к api.cloudflare.com будет зарезан и ИИ-слой "
                    "там не заведётся; это не баг тула. Работает офлайн-часть "
                    "(грепы + досье), либо мобильный хотспот — см. README.txt)" % e)

            if not data.get("success", False):
                errs = data.get("errors") or []
                msg = "; ".join(str(e.get("message", "")) for e in errs)
                code = ";".join(str(e.get("code", "")) for e in errs)
                etype, human = self._classify_http_error(0, msg + " " + code)
                if etype == "quota":
                    raise QuotaExceeded(human)
                raise AIError(human if etype != "other" else (msg or "неизвестная ошибка API"))

            result = data.get("result") or {}
            usage = (result.get("usage") or {}).get("neurons") or 0
            text = self._extract_text(result)
            if not text:
                raise AIError("пустой ответ модели (проверь max_tokens/reasoning)")
            return text, float(usage)
        raise AIError("все токены отклонены: %s" % last_auth)

    @staticmethod
    def _extract_text(result):
        """Достаём текст ответа из любого известного формата CF Workers AI.
        1) OpenAI-совместимый: result.choices[0].message.content (gpt-oss, kimi,
           mistral...) — content может быть строкой ИЛИ списком блоков
           [{"type":"text","text":"..."}, ...] (так отдаёт gpt-oss при
           мультимодальном ответе).
        2) CF-нативный: result.response (llama, qwen старого формата).
        3) Если content пуст, а есть reasoning — берём reasoning (модель
           «думала вслух», но не дописала ответ — лучше так, чем ничего)."""
        if isinstance(result.get("choices"), list) and result["choices"]:
            msg = result["choices"][0].get("message") or {}
            content = msg.get("content")
            if isinstance(content, list):
                # список блоков: склеиваем текстовые блоки
                parts = []
                for block in content:
                    if isinstance(block, dict) and block.get("text"):
                        parts.append(block["text"])
                    elif isinstance(block, str):
                        parts.append(block)
                content = "\n".join(parts)
            if content:
                return content
            reasoning = msg.get("reasoning") or msg.get("reasoning_content")
            if reasoning:
                return reasoning
        # CF-нативный формат (qwen и др.)
        if isinstance(result.get("response"), str):
            return result["response"]
        return ""

    # ------------------------------------------------------------------
    def ask_cascade(self, messages, max_tokens=6000):
        """Каскад: главная модель → фолбэки. Возвращает (text, model, neurons)."""
        if self.used >= self.budget:
            raise QuotaExceeded("бюджет нейронов (%.0f) уже израсходован" % self.budget)
        last_err = None
        for model in self.models:
            try:
                text, used = self.chat(model, messages, max_tokens)
                self.used += used
                return text, model, used
            except QuotaExceeded:
                raise
            except AIError as e:
                last_err = e
                continue
        raise AIError("все модели недоступны: %s" % last_err)

    def usage_report(self):
        return "нейронов израсходовано: %.1f из бюджета %.0f" % (self.used, self.budget)


# ----------------------------------------------------------------------
SYSTEM_PROMPT = """Ты — пентестер-защитник на Attack-Defense CTF (InnoCTF Junior, ForcAD).
Тебе дают код сервиса с вулнбокса твоей команды. Твоя задача — найти уязвимости,
которые атакующие используют, чтобы красть флаги, и предложить МИНИМАЛЬНЫЕ патчи.

ЖЁСТКИЕ ПРАВИЛА ПАТЧЕЙ:
1. Один баг = один патч. Минимальный дифф, ничего вокруг.
2. Патч НЕ должен сломать чекер: не менять порты, пути, формат ответов, статус-коды, схему БД.
3. Не переписывать архитектуру, не «чинить заодно» остальное.
4. Если сомневаешься в находке — пометь [НЕУВЕРЕН] и объясни, как проверить руками.
5. Проверь все места, куда чекер кладёт флаг (данные пользователей): чтение чужих записей = главный источник утечки.

ФОРМАТ ОТВЕТА (markdown, на русском, только уязвимости, никакой воды):

### [КЛАСС] файл:строка — краткое имя
- **Что:** 1-2 предложения: как это эксплуатируют и почему уведут флаги.
- **Патч:**
```(язык)
БЫЛО: <текущий код>
СТАЛО: <исправленный код>
```
- **Чекер жив:** почему патч не ломает пользовательский сценарий.
- **Проверка:** как воспроизвести атаку руками и как проверить после патча.
"""

USER_TMPL = """# Сервис: {name}
Стек: {stack}
Файлов: {n_files} (~{n_lines} строк). Совпадения с известными сервисами прошлых игр: {matches}.

## Инвентарь (путь — размер)
{inventory}

## Маршруты (файл: роут)
{routes}

## Секреты в конфигах
{secrets}

## Находки офлайн-сканера (патчбук) — проверь каждую и расширь
{findings}

## Досье известных сервисов-предков (если совпали) — используй как подсказку, но проверяй по коду
{dossier}

## Код подозрительных файлов (фрагменты)
{files}

Задача: найди УЯЗВИМОСТИ, через которые уведут флаги. Проверь все находки сканера выше (возможно ложное срабатывание — пометь). Добавь то, чего не видит сканер: логика авторизации, IDOR, гонки, слабая криптография, инъекции в нестандартных местах. Отвечай строго в заданном формате markdown, на русском.
"""


def build_case(name, scan, matches):
    inv = "\n".join("`%s` — %d Б" % (r, s) for r, s in scan["files"][:80]) or "—"
    routes = "\n".join("`%s`: `%s`" % (r, p) for r, p in scan["routes"][:60]) or "—"
    secrets = "\n".join("`%s:%d` %s = ...%s" % (s["file"], s["line"], s["key"], s["value_tail"])
                         for s in scan["env_secrets"]) or "—"
    findings = "\n".join(
        "[%s] `%s:%d` — %s\n    код: %s" % (f["sev"], f["file"], f["line"], f["hint"], f["code"][:140])
        for f in scan["findings"][:40]) or "—"
    dsr = "—"
    tops = [m for m in matches if m["score"] >= 6][:2]
    if tops:
        parts = []
        for m in tops:
            d = m["dossier"]
            parts.append("### %s (совпадение %d%%)\n%s" % (d["title"], int(m["confidence"] * 100),
                          "\n".join("- [%s] %s — %s" % (v["class"], v["where"], v["what"]) for v in d["vulns"])))
        dsr = "\n\n".join(parts)

    # топ-файлы по подозрительности
    score = {}
    for f in scan["findings"]:
        w = {"crit": 5, "high": 3, "med": 1, "info": 0}[f["sev"]]
        score[f["file"]] = score.get(f["file"], 0) + w
    top_files = sorted(score.items(), key=lambda x: -x[1])[:6]
    chunks = []
    total = 0
    for rel, _ in top_files:
        text = scan["texts"].get(rel, "")
        if not text:
            continue
        cut = text[:8000]
        if total + len(cut) > 42000:
            cut = cut[: max(4000, 42000 - total)]
        total += len(cut)
        chunks.append("### %s\n```\n%s\n```" % (rel, cut))
    files_md = "\n\n".join(chunks) or "—"

    mtxt = "; ".join("%s (%d%%)" % (m["dossier"]["title"], int(m["confidence"] * 100)) for m in tops) or "нет"

    return USER_TMPL.format(
        name=name, stack=", ".join(scan["stack"]) or "?", n_files=scan["n_files"],
        n_lines=scan["n_lines"], matches=mtxt, inventory=inv, routes=routes,
        secrets=secrets, findings=findings, dossier=dsr, files=files_md,
    )


def clean_ai_output(text):
    """Убираем обёртки из ответа модели."""
    text = text.strip()
    text = re.sub(r"^```(?:markdown|md)?\s*", "", text)
    text = re.sub(r"\s*```\s*$", "", text)
    return text.strip()
