#!/usr/bin/env bash
# ============================================================
#  TRIPWIRE v2 — «мины» без разрушения: канарейки-пустышки + детектор
#
#  ИДЕЯ (почему это парализует соперника, но нам ничего не ломает):
#    Соперник зайдёт к нам по SSH (у всех был дефолтный пароль) и
#    запустит свою ферму-охотника. Охотник ищет строки формата флага
#    и СДАЁТ их на чек-систему. Мы подкладываем МНОГО строк формата
#    флага, которые НЕ являются живыми флагами:
#      -> его ферма сдаст их -> ОТКАЗ (потраченные попытки/квота)
#      -> если платформа штрафует за неверный флаг — ему ещё и минус
#      -> мы в этот момент УЖЕ ЗНАЕМ, что он внутри (вотчдог ниже)
#    Наши же настоящие флаги лежат в сервисах — их tripwire не трогает,
#    мы их сдаём как обычно. Поэтому: сопернику плохо, нам — ничего.
#
#  ЧТО ДЕЛАЕТ install:
#    1) рассыпает ~30 пустышек в правдоподобных местах:
#       /flags-decoy/ (главная директория), $AP_ROOT/round-flags.txt,
#       /var/backups/.flags_dump
#    2) пишет все значения в canaries.txt РЯДОМ С ТУЛОМ — farm.py
#       читает этот файл и НИКОГДА не сдаст пустышку (защита от того,
#       чтобы мы сами не сдали свою же мину)
#    3) ставит вотчдог: раз в 5 сек проверяет канарейки и
#       authorized_keys/passwd -> тревога в лог + wall на терминалы
#
#  ЗАПУСК (на вулнбоксе, до 10:40):
#    sudo bash tripwire.sh install     # поставить всё
#    bash tripwire.sh status           # что поставлено, что трогали
#    sudo bash tripwire.sh remove      # убрать всё
#
#  ВАЖНО ДЛЯ СВОИХ:
#    - после install скопируй canaries.txt на СВОЮ Kali в папку тулов
#      (scp user@10.2.<X>.2:~/autopatch/canaries.txt .) — тогда и ферма,
#      и ручная сдача отказываются брать пустышки
#    - файлы в DECOY выглядят как флаги — СВОИ НЕ СДАВАТЬ (ферма сама
#      их отсечёт, но если сдаёшь руками — смотри canaries.txt)
#
#  ТЕСТОВЫЙ РЕЖИМ (без рута, для labtest.sh):
#    AP_ROOT=/tmp/xxx TRIP_TEST=1 bash tripwire.sh install
# ============================================================
set -uo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"

# --- подстройка вводных: settings.env пишет tune.py -------------------
# (если файла нет — работают дефолты ниже; менять вводные через tune.py)
[ -f "$HERE/settings.env" ] && . "$HERE/settings.env"

AP_ROOT="${AP_ROOT:-/root}"          # "дом" админа; в тестах переопределяется
DECOY="${DECOY:-/flags-decoy}"       # главная директория канареек
CANARY_LEN="${CANARY_ALNUM_LEN:-31}" # длина символьной части флага
CANARY_SUFFIX="${CANARY_SUFFIX:-=}"  # хвост флага
# ФАКТ из исходников ForcAD: флаг = БУКВА_СЕРВИСА + 30 случайных [A-Z0-9] + '='.
# Если впишем первые буквы наших сервисов (tune.py -> SERVICE_LETTERS),
# канарейки будут неотличимы от живых флагов этих сервисов.
SERVICE_LETTERS="${SERVICE_LETTERS:-}"
CANARIES_FILE="$HERE/canaries.txt"   # ЕДИНЫЙ список пустышек (для farm.py)
WATCHER="$AP_ROOT/ap-tripwatch.sh"
PIDFILE="$AP_ROOT/.tripwatch.pid"
LOG="$AP_ROOT/tripwire.log"
MARKER="$AP_ROOT/.tripwatch.marker"       # маркер для канареек (время последней проверки)
KEYMARKER="$AP_ROOT/.tripwatch.keys"       # ОТДЕЛЬНЫЙ маркер для учёток/ключей:
                                           # два независимых, чтобы одна тревога
                                           # не «съедала» другую в том же цикле

say() { printf '\033[1;36m>> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m!! %s\033[0m\n' "$*"; }
die() { printf '\033[1;31mXX %s\033[0m\n' "$*"; exit 1; }

# рут нужен только в боевом режиме (пишем в /root, /usr/local и т.п.)
if [ "$AP_ROOT" = "/root" ] && [ "$(id -u)" -ne 0 ]; then
    die "запусти от root: sudo bash tripwire.sh (или задай AP_ROOT=/tmp/... для теста)"
fi

# --- генератор пустышки формата ForcAD --------------------------------
# /dev/urandom -> base64 -> оставляем только A-Z0-9 -> нужная длина.
# Если задан SERVICE_LETTERS (первые буквы наших сервисов), первая буква
# пустышки = буква сервиса: по формату её НЕ ОТЛИЧИТЬ от живого флага.
rand_canary() {
    local first=""
    if [ -n "$SERVICE_LETTERS" ]; then
        # случайная буква из списка наших сервисов
        local L="${SERVICE_LETTERS}"  # например "S,T,E"
        local n=$(echo "$L" | tr ',' '\n' | wc -l)
        first=$(echo "$L" | tr ',' '\n' | sed -n "$((RANDOM % n + 1))p")
    fi
    local body=$(head -c 400 /dev/urandom | base64 | tr -dc 'A-Z0-9' | head -c $((CANARY_LEN - ${#first})))
    echo "${first}${body}${CANARY_SUFFIX}"
}

new_canary_line() {
    printf '%s\n' "$(rand_canary)"
}

# --- установка ---------------------------------------------------------
install_all() {
    say "канарейки-пустышки: главная директория $DECOY"
    mkdir -p "$DECOY"
    chmod 755 "$DECOY"

    # Единый список: сначала заголовок (farm.py строки с # игнорирует)
    : > "$CANARIES_FILE"
    echo "# НАШИ канарейки-пустышки. Сдавать НЕЛЬЗЯ (см. README, раздел TRIPWIRE)." >> "$CANARIES_FILE"
    echo "# Сгенерировано tripwire.sh $(date '+%Y-%m-%d %H:%M'). Обновляется при каждом install." >> "$CANARIES_FILE"

    # 12 файлов по 2-3 пустышки в главной директории — выглядит как
    # «дамп раундовых флагов», куда первым делом полезет чужой охотник
    for i in $(seq 1 12); do
        {
            echo "# round $(date +%Y%m%d)"
            new_canary_line
            new_canary_line
            new_canary_line
        } > "$DECOY/flag_round_$i.txt"
    done
    # подпись значений в общий список (grep -E интервал {31})
    PATTERN="[A-Z0-9]{${CANARY_LEN}}${CANARY_SUFFIX}"
    grep -hoE "$PATTERN" "$DECOY"/flag_round_*.txt >> "$CANARIES_FILE" 2>/dev/null || true

    # разброс: правдоподобные места, куда смотрят вторыми
    say "канарейки: разброс по правдоподобным местам"
    mkdir -p "$AP_ROOT/notes" 2>/dev/null || mkdir -p "$AP_ROOT"
    {
        echo "# internal dump, do not share"
        new_canary_line; new_canary_line
    } > "$AP_ROOT/round-flags.txt"
    {
        echo "# backup of flag storage"
        new_canary_line; new_canary_line
    } > "$AP_ROOT/notes/flags-old.txt" 2>/dev/null || true
    {
        echo "# legacy storage"
        new_canary_line
    } > /var/backups/.flags_dump 2>/dev/null || warn "нет доступа к /var/backups (не критично)"
    grep -hoE "$PATTERN" \
        "$AP_ROOT/round-flags.txt" "$AP_ROOT/notes/flags-old.txt" /var/backups/.flags_dump 2>/dev/null >> "$CANARIES_FILE" \
        || true

    # права: пустышки должны ЧИТАТЬСЯ всеми (иначе соперник их не возьмёт)
    chmod 644 "$DECOY"/flag_round_*.txt 2>/dev/null
    chmod 644 "$AP_ROOT/round-flags.txt" "$AP_ROOT/notes/flags-old.txt" 2>/dev/null
    chmod 600 "$CANARIES_FILE"
    say "пустышек в canaries.txt: $(grep -cE '[A-Z0-9]' "$CANARIES_FILE")"

    # --- bait-файлы: места, куда первым делом лезут фермы новичков -------
    # Сами файлы НЕ ТРОГАЕМ, если уже существуют (не ломаем свои сервисы).
    # Каждая пустышка попадает в canaries.txt — наша ферма их не сдаст.
    say "bait-файлы в «джуниорских» местах"
    PATTERN="[A-Z0-9]{${CANARY_LEN}}${CANARY_SUFFIX}"
    seed_bait() {
        # $1 — путь; создаём ТОЛЬКО если файла нет, кладём 2 пустышки.
        # Созданные пути пишем в манифест .tripwire.baits — remove_all
        # удаляет ТОЛЬКО их (не трогает настоящие файлы, например реальный .git).
        local f="$1"
        [ -e "$f" ] && return 0
        mkdir -p "$(dirname "$f")" 2>/dev/null || return 0
        {
            new_canary_line
            new_canary_line
        } > "$f" 2>/dev/null || return 0
        chmod 644 "$f" 2>/dev/null
        grep -hoE "$PATTERN" "$f" 2>/dev/null >> "$CANARIES_FILE" || true
        echo "$f" >> "$AP_ROOT/.tripwire.baits"
    }
    seed_bait /flag
    seed_bait /flag.txt
    seed_bait "$AP_ROOT/flag.txt"
    seed_bait /srv/flag.txt
    seed_bait /var/www/html/flag.txt
    seed_bait /var/www/flag.txt
    seed_bait /backup/db.sql
    seed_bait /var/www/html/.env
    seed_bait /var/www/html/.git/config
    seed_bait /var/www/html/robots.txt
    seed_bait /var/www/html/.well-known/security.txt
    seed_bait /opt/flags.txt
    for h in /home/*; do
        [ -d "$h" ] && seed_bait "$h/flag.txt"
    done
    say "bait-файлов создано: $(grep -cE '[A-Z0-9]' "$CANARIES_FILE") всего пустышек"
    say "манифест bait-путей: $AP_ROOT/.tripwire.baits"

    # --- вотчдог: детектор вторжений (ТОЛЬКО чтение и лог, ничего не ломает)
    say "вотчдог (детектор вторжений)"
    cat > "$WATCHER" <<EOF
#!/bin/sh
# ap-tripwatch — детектор. Ничего не удаляет и не ломает: только лог + тревога.
DECOY="$DECOY"
LOG="$LOG"
MARKER="$MARKER"
KEYMARKER="$KEYMARKER"
while true; do
    # 1) трогали ли канарейки (читали/меняли — точнее: новее маркера)
    if [ -e "\$DECOY" ] && find "\$DECOY" -newer "\$MARKER" 2>/dev/null | grep -q .; then
        echo "[\$(date '+%H:%M:%S')] КАНАРЕЙКА ТРОНУТА: кто-то читает \$DECOY — проверь last/who" >> "\$LOG"
        wall "!! TRIPWIRE: кто-то в системе (читает \$DECOY). Проверь last, who, ротируй пароль!" 2>/dev/null
        touch "\$MARKER"
    fi
    # 2) не подложили ли чужой ключ в authorized_keys / не меняли ли учётки
    # (свой маркер — не зависит от канареечной ветки)
    for f in "$AP_ROOT/.ssh/authorized_keys" /etc/passwd /etc/shadow; do
        if [ -e "\$f" ] && [ "\$f" -nt "\$KEYMARKER" ]; then
            echo "[\$(date '+%H:%M:%S')] ИЗМЕНЁН: \$f — проверь содержимое!" >> "\$LOG"
            wall "!! TRIPWIRE: изменён \$f — смотри \$LOG" 2>/dev/null
        fi
    done
    touch "\$KEYMARKER"
    sleep 5
done
EOF
    chmod 700 "$WATCHER"
    touch "$MARKER" "$KEYMARKER"
    if [ "${TRIP_TEST:-0}" = "1" ]; then
        say "тестовый режим: вотчдог НЕ запускаем (лабтест сам проверит генерацию)"
    else
        nohup "$WATCHER" >/dev/null 2>&1 &
        echo $! > "$PIDFILE"
        say "вотчдог запущен (pid $(cat "$PIDFILE" 2>/dev/null)), лог: $LOG"
    fi

    say "ГОТОВО. Дальше:"
    echo "   1) скопируй canaries.txt на свою Kali в папку тула:"
    echo "      scp $(id -un)@10.2.<X>.2:$HERE/canaries.txt <путь-тула>/"
    echo "      (тогда farm.py и ручная сдача НЕ возьмут пустышку)"
    echo "   2) проверка: bash tripwire.sh status"
}

# --- статус ------------------------------------------------------------
status() {
    say "статус tripwire"
    if [ -d "$DECOY" ]; then
        echo " -- канарейки: $(ls "$DECOY" 2>/dev/null | wc -l) файлов в $DECOY"
        echo " -- пустышек в canaries.txt: $(grep -cE '[A-Z0-9]' "$CANARIES_FILE" 2>/dev/null || echo 0)"
    else
        echo " -- канареек НЕТ (запусти install)"
    fi
    if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
        echo " -- вотчдог: жив (pid $(cat "$PIDFILE"))"
    else
        echo " -- вотчдог: НЕ работает"
    fi
    echo " -- последние тревоги:"
    tail -5 "$LOG" 2>/dev/null || echo "    (пусто — никто не лазил)"
}

# --- снятие ------------------------------------------------------------
remove_all() {
    [ -f "$PIDFILE" ] && kill "$(cat "$PIDFILE")" 2>/dev/null
    rm -f "$PIDFILE"
    # удаляем ТОЛЬКО то, что сами создали: манифест bait-путей + наши каталоги.
    # Настоящие файлы сервисов (в т.ч. реальный .git) не трогаем.
    if [ -f "$AP_ROOT/.tripwire.baits" ]; then
        while IFS= read -r f; do
            [ -e "$f" ] && rm -f "$f"
        done < "$AP_ROOT/.tripwire.baits"
    fi
    rm -rf "$DECOY" "$WATCHER" "$MARKER" "$KEYMARKER" \
        "$AP_ROOT/round-flags.txt" "$AP_ROOT/notes/flags-old.txt" \
        "$AP_ROOT/.tripwire.baits" /var/backups/.flags_dump 2>/dev/null
    say "канарейки, bait-файлы и вотчдог сняты (лог оставлен: $LOG)"
    warn "canaries.txt НЕ удалён — ферма должна помнить пустышки и после снятия"
}

case "${1:-}" in
    install) install_all ;;
    status)  status ;;
    remove)  remove_all ;;
    *) echo "использование: bash tripwire.sh install|status|remove"; exit 1 ;;
esac
