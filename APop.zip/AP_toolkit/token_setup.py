#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TOKEN SETUP — одна кнопка: сырой токен Cloudflare (cfut_...) -> строка
для ap/config.json. Нужен при первом развёртывании кита и при замене токена.

ПОЧЕМУ ТАК: токен лежит в config.json в обфусцированном виде (XOR + base64).
Это НЕ шифрование — это защита от «случайно увидел и заскринил». Тот, кто
хочет достать токен, достанет: значит публичная копия кита ВСЕГДА ходит
с ПУСТЫМИ токенами, а живые значения вбиваются локально через этот скрипт.

ЗАПУСК:
  python3 token_setup.py cfut_ВАШТОКЕН            # основной
  python3 token_setup.py cfut_ВАШТОКЕН --slot 2   # запасной

ГДЕ ВЗЯТЬ ТОКЕН: Cloudflare Dashboard -> Workers AI -> API Tokens.
Бесплатная квота: 10 000 нейронов/сутки, сброс в 00:00 UTC (03:00 МСК).
"""
import argparse
import base64
import os
import sys

# Тот же ключ, что в ap/util.py::deobfuscate — меняться должны синхронно!
KEY = b"AP-k-e-y-2026!!"


def obfuscate(s, key=KEY):
    """Обратное к deobfuscate: XOR по ключу + urlsafe-base64."""
    raw = bytes(ord(c) ^ key[i % len(key)] for i, c in enumerate(s))
    return base64.urlsafe_b64encode(raw).decode("ascii")


def main():
    ap = argparse.ArgumentParser(description="Обфускация CF-токена для config.json")
    ap.add_argument("token", nargs="?", help="сырой токен cfut_...")
    ap.add_argument("--slot", type=int, choices=(1, 2), default=1,
                    help="1 = token_obf (основной), 2 = token2_obf (запасной)")
    args = ap.parse_args()

    token = args.token or input("Вставь сырой токен cfut_...: ").strip()
    if not token.startswith("cfut_"):
        print("!! Токен Cloudflare Workers AI начинается с cfut_. "
              "Похоже, вставлено что-то другое.")
        sys.exit(2)

    obf = obfuscate(token)

    # самопроверка: раскодируем обратно и сравним (roundtrip)
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from ap.util import deobfuscate
    if deobfuscate(obf) != token:
        print("!! Внутренняя ошибка roundtrip — сообщи разработчику кита.")
        sys.exit(3)

    print("Готово. Вставь эту строку в ap/config.json:")
    print('  "%s": "%s",' % ("token_obf" if args.slot == 1 else "token2_obf", obf))
    print("Проверка: python3 ap_quota_probe.py")


if __name__ == "__main__":
    main()
